# STM32G431 变频合板硬件

2026-11-06：已绘制 **Rev B 原生 KiCad 10 原理图，共 18 页**，并建立 **PCB 0.1：200×140 mm、四层**。一颗 STM32G431RBT6、控制与采样保护、三颗半桥驱动、一套三相桥及一路制动在同一 PCB。当前为硬件审查稿；PFC 电源板绘图暂停。

同日按用户意见重排图面：**功能模块内部用直接连线，模块之间可以用网络标签连接**，同页也不必用长线把所有模块串在一起。电源/地采用局部母线或标准符号；跨页信号用全局标签，页内模块间信号优先用同名局部标签。连续功率路径、栅极/自举回路、运放反馈、采样调理等模块内部应能沿线阅读，后续修改沿用此画法。[重排前后全网表等价检查](review/readability_equivalence.txt)

- [KiCad 工程](inverter.kicad_pro) / [原理图入口](inverter.kicad_sch)
- [十八页 PDF](review/inverter.pdf) / [实际位号 BOM](bom/bom.csv)
- [G431 完整引脚表](STM32G431RBT6_pin_plan.csv) / [引脚与资源说明](../docs/pin_assignment.md)
- [ERC 报告](review/erc.rpt)：0 错误、0 警告；没有为本版新增排除或放宽检查规则。
- [独立网表核对](review/connectivity_check.txt)：64 脚、八路 ADC、板内控制/外部接口和原硬件保护逻辑通过。
- [设计审查与未定项](design_review.md)
- [PCB 原生板文件](inverter.kicad_pcb) / [PCB 设计与未定项](PCB_REVIEW.md)
- [PCB 俯视预览](review/pcb_top.png) / [顶层铜与丝印](review/pcb_front.svg) / [底层铜](review/pcb_back.svg)
- [PCB 独立读回检查](review/pcb_check.txt) / [最终 DRC](review/pcb_drc.json)

PCB 0.1 已完成本轮布局与布线：最终填铜 DRC **0 违规、0 未连接、0 原理图一致性问题**；313 个位号与 933 个实体焊盘独立核对通过。仍为审查稿，封装物料、铜厚工艺和热/动态验证按 [PCB 审查记录](PCB_REVIEW.md) 继续定稿。

## 本版电路

母线 12～60 V，直流输入最大 10 A，每相连续 10 Arms 为设计目标；桥 PWM 20 kHz。保留两只 220 µF/100 V、七只 TO-263 MOS、三路低端分流和 INA241、四路电压缓冲及外接 NTC。外部比较器、故障锁存和六路硬件 PWM 封锁继续工作，故障另接 TIM1 BKIN。制动由本板 MCU 的独立 TIM8 输出控制，J5 接外部电阻。

辅助电源独立输入 12～24 V，板内产生 12 V、5 V、3.3 V。原 controller 的 5 V 分支改为可选传感器电源，总目标 0.5 A；外设供电连接默认 DNP。MCU 最小系统包含 VDD/VBAT 去耦、VDDA/VREF、监控复位、按键、SWD 和 BOOT0 下拉；HSE 晶体及负载电容为 DNP 候选。

本图保留两路 ABZ、两路独立 SPI、一路 TTL、SWD、可选经典 CAN、五只指示灯。ABZ/SPI 按 3.3 V 单端逻辑绘制，具体编码器/模块及接口机械型号仍需匹配。取消旧 J1 的 24 脚控制排线和 J6 制动命令口；ENABLE、FAULT_N、PWM、采样、BRAKE 已成为板内网络。

三相端子为原始 U/V/W PWM，未加入尚未定型的交流源输出 LC。母线不设置独立预充或专用放电支路。

## 文件与定稿边界

BOM 共 **313 条位号记录，含测试点及 16 条默认 DNP**。全部已有 PCB 封装，其中 19 个连接器、保险、电感、按键是[机械候选](tools/pcb_footprint_candidates.json)，仍需匹配实际立创完整料号和额定。普通国巨阻容等完整料号、电源预算、热设计、采样窗口、保护时序、输入钳位和外接接口保护仍需完成，不能直接按此采购装配。

公共库没有修改。G431 和原 IRFS4227、D1、小信号管使用 [工程草稿库](InverterLocal_README.md)，不等同于公共库完成入库。旧十三页分板方案及其 BOM/报告已保存在 [Rev A 归档](../history/split_rev_a_2026-11-06.zip)。当前以原生 KiCad 文件为准，重导出方法见 [工具说明](tools/README.md)。
