# 工程专用草稿符号

`InverterLocal.kicad_sym` 为本轮 inverter 原理图的项目库，未修改公共 `kicad_library`。三个符号均标 `project_draft`；不是共享库 reviewed 或实物验证物料。

| 符号 | 编号依据 | 复用的图形与封装 |
| --- | --- | --- |
| IRFS4227TRLPBF | Infineon IRFS4227 PD-96131A：1G/2D/3S，tab=D | 现有同脚序 MOS 图形，明确关联官方 `TO-263-3_TabPin2`，不使用旧 TO-220；新封装/热和采购待核 |
| MMBT3904LT1G | onsemi MMBT3904L Rev 15：1B/2E/3C | 官方 `Transistor_BJT:Q_NPN_BEC`、SOT-23；C81464 / https://item.szlcsc.com/82615.html |
| STPS40150CG_TR_CANDIDATE | ST STPS40150C：1A1/2K/3A2，tab=K | 官方 `Device:D_Schottky_AKA`、TO-263；仅主入口候选，国内采购/热未定 |

原厂 PDF 和技术依据链接见 [设计审查](design_review.md)；下载的 IRFS 原厂副本位于 `../reference/datasheets/Infineon_IRFS4227.pdf`。不要据此宣称公共库物料已经建好。

官方库复用来源：[KiCad symbols](https://gitlab.com/kicad/libraries/kicad-symbols)、[KiCad footprints](https://gitlab.com/kicad/libraries/kicad-footprints)。许可为 CC BY-SA 4.0 及设计使用例外，见 [KiCad 库许可](https://www.kicad.org/libraries/license/)。现有共享库来源记录保留在其 `docs/THIRD_PARTY.md`。工程记录使用文件哈希，不给制造商规格书重新授予许可。
