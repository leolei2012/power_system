# Inverter Rev A 原理图审查记录

2026-11-05 架构变更：用户确定控制、驱动与逆变功率级合板，MCU 改为 **STM32G431**。当前依据见 [合板方案](../../docs/integrated_board.md)。本文下方 LKS、独立 controller、24 脚板间接口及旧引脚/软件预算属于上一版记录；旧 KiCad/BOM/检查结果不代表新合板版本已完成。已确定每板一颗 MCU，分变频板与电源板，取消单 MCU 同时控制两路逆变和 PFC。LLC 在电源板恢复讨论，具体配置、接口和 MCU 完整后缀待评估。


2026-11-01。已按用户要求建立原生 KiCad 10 第一版草稿，共 13 页；目前用于审查电路和选型，不是生产发布版本。controller 原生文件未修改。本稿以既有 12~60 V 母线、输入最大 10 A、每相连续 10 Arms 设计目标、桥 PWM 20 kHz、±20 A 过流和 65 V 过压要求展开，未以静态连通代替额定验证。

## 工程与当前实现

- 入口：[inverter.kicad_pro](inverter.kicad_pro) / [inverter.kicad_sch](inverter.kicad_sch)。
- [十三页 PDF](review/inverter.pdf)、[实际位号 BOM](bom/bom.csv)、[ERC](review/erc.rpt)、[独立网表核对](review/connectivity_check.txt)。
- 214 条物理器件/测试点记录；D2 为唯一默认 DNP 的 TVS 候选。所有具体未定料号、额定及封装在 BOM 保留 TBD 或候选状态；不能据此直接下装配订单。

| 页码 | 功能 |
| --- | --- |
| 1 | 总览与原生层级导航 |
| 2 | 独立 12~24 V 辅助输入、TPS26600 保护及本地复位 |
| 3 | TPS55165 升降压产生 12 V，VREG、启动、PG 与反馈外围 |
| 4 | AP63205 5 V、TPS7A20 3.3 V、TPS2553 controller 分支及 TPS3808 监控 |
| 5 | 母线入口、两只 220 uF 和两只 2.2 uF、外接制动电阻及驱动 |
| 6~8 | 三个独立半桥，MOS、驱动、自举、栅极阻容及分流 |
| 9 | 三路 INA241A1、1.65 V 偏置及过流窗口参考 |
| 10 | 四路 50:1 电压分压/缓冲、过压参考与外接 NTC |
| 11 | 三相正负过流、母线过压、12 V 驱动轨欠压共八路比较器 |
| 12 | 故障汇总、锁存、延迟复位、许可和开集电极通知 |
| 13 | 24 脚控制口、六路 PWM 与门、逻辑供电及未用门处理 |

母线没有独立预充/限浪涌支路或专用放电电阻；辅助 eFuse 的限流/斜率控制继续保留，二者不混淆。制动由 controller 的独立 BRAKE 命令控制，不与三相 ENABLE 或桥故障许可相与。J5 的 BR+ 接 VBUS、BR_SW 接制动 MOS 漏极；不用外接电阻时开路，不能短接。

输出端按 ATK 功率桥画为直接 U/V/W PWM。原 470 uH/10 uF 可切换 LC 是未冻结候选，本稿没有把它当作已确认硬件装入；因此相电压采在桥开关节点，不能称为 LC 后的交流源采样。交流源滤波/阻尼及是否放本板仍须另定。

## 功率桥和驱动回流

Q1~Q6 为已选 IRFS4227TRLPBF，Q7 为制动，同用 TO-263。按 [Infineon IRFS4227 资料](https://www.infineon.com/assets/row/public/documents/24/49/infineon-irfs4227-datasheet-en.pdf)核对 G=1、D=2、S=3，大焊盘也是 2/漏极；工程符号没有借用旧 IRFB 的 TO-220 封装。主桥冷态导通损耗粗估仍约 3×10²×0.026=7.8 W，热态、开关、反向恢复和死区损耗另计。

每相独立 SOURCE 节点连接该下管源极、对应驱动 COM、分流高端、低侧栅极下拉及就近 VCC 去耦返回端。三只分流低端和公共辅助回流才接 GND/DC−；没有用驱动公共地跨接分流。高侧栅极下拉与自举返回端均接所属 PHASE，不能接 GND。跨页同名网络为板内连接，不表示另有实体驱动板。

RS1~RS3 暂选 HoJLR2512-3W-5mR-1% / C2903482，2512 两端器件，取样走 Kelvin 分支。厂家系列规格书离线副本在公共库 `datasheets/Milliohm_HoJLR2512-3W-5mR-1_lcsc.pdf`，2020-04-13 Ho-A0；具体国内商品链接、脉冲额定、热降额及量产封装仍待核，不冒充已建库四端分流器。10 A 通过时 0.5 W，瞬时 20 A 时 2 W，不能代替故障能量验证。

U7~U9 为 2ED2182S06FXUMA1，依 [V2.32 规格书](https://www.infineon.com/assets/row/public/documents/24/49/infineon-2ed2182-4-s06f-j-datasheet-en.pdf)连接全部八脚。使用内置自举二极管，自举改为 2.2 uF/25 V/1206 并 100 nF 的起始配置，目标是偏压/公差后有效容量至少 1 uF；没有原样照抄旧 10 uF 候选。每颗驱动 VCC 就近 4.7 uF +100 nF，回到所属 SOURCE。栅极串 15 Ω/0805、栅源 10 kΩ 为试验初值，需看波形调整。

自举电容计算起点：以 MOS 最大 Qg≈98 nC、驱动 IQBS 典型 170 uA、单次导通 50 us 和漏电 12.5 uA 为简化例，电荷约 107 nC；有效 1 uF 时下降约 0.107 V。不能由此保证最终 10 V 栅压：内部二极管最大压降只在指定电流条件给出，需叠加 12 V 转换误差、补电电流、下侧分流压降和驱动压降。**12 V 最差角点是否仍满足 MOS 的 10 V 导通电阻测试条件是待定项**。驱动内部 UVLO 动作点比 10 V 更低，不等于该导通电阻已经得到保证。

驱动典型内部死区 400 ns、数据表范围 260~540 ns，不能当作整个桥已经验证的死区。首次启动补电、最大占空比、最小低侧导通时间、瞬态负 VS 和栅极振铃仍需验证；本板不支持未经设计的高侧无限期常导通。

## 辅助供电的具体接法

U1 为 TPS26600PWPR，**8 脚 RTN 与 17 脚 EP 独立成参考岛，不与 9 脚系统 GND 短接**。UV/OV、ILIM、MODE、dVdT 电阻电容返回 RTN。MODE 通过 402 kΩ 接 RTN 选择限流锁断；直接接 RTN 会选到自动重试，本稿没有这样接。SHDN 通过 100 kΩ 从输入上拉，SW1 拉到 RTN 用于辅助入口复位；它不是已取消的功率板 RESET_N。[TI TPS2660 Rev G](https://www.ti.com/lit/ds/symlink/tps2660.pdf)

UV 78.7k/10k、OV 221k/10k，按典型 1.19 V 参考得到上升欠压约 10.555 V、过压约 27.489 V；UV 下降另有芯片迟滞。ILIM 7.87 kΩ 对应名义约 1.50 A，dVdT 22 nF 在 24 V 下名义斜坡约 4.224 ms。门限、电阻误差、SOA、输入电容与两路转换器的启动负载仍须计算，不能据名义值宣称浪涌验证完成。

U2 固定 12 V：VREG_Q、VOS_FB 均接 VREG，VOUT_SENSE 接输出；VREG 4.7 uF 只为芯片内部偏置，不供外部负载。IGN 跟随保护后的辅助输入，IGN_PWRL/PS/SS_EN 置低，不依赖 MCU 自举启动。两只 100 nF 分别跨 BST1/L1、BST2/L2；L1/L2 引脚之间为 4.7 uH 电感。[TI TPS55165-Q1 Rev A](https://www.ti.com/lit/ds/symlink/tps55165-q1.pdf)

原厂 12 V 应用明确要求 PG 从外部 5 V 经电阻上拉，本稿用 10 kΩ 上拉，之后 10 kΩ/20 kΩ 分压到逻辑输入；包含上拉在内的三电阻分压使高态名义为 **2.5 V**，不是 3.33 V，也不把 PG 拉到 12 V。PG_DLY=100 kΩ 是原厂已列出的延时配置，相关章节对直接接地的文字存在不同名义时长，不使用该接地值作定稿依据。

L1 选型目标 4.7 uH、DCR≤40 mΩ、Isat≥5 A。原厂要求覆盖内部峰值限流最大 4.5 A，不只按 0.25 A 输出预算选饱和电流。L2 同为 4.7 uH/Isat≥5 A 的起始目标，需覆盖 AP63205 峰值/谷值限流、短路过冲、DCR 和温升；**两只完整电感和焊盘均未定**。

U3 AP63205 FB 直接检测 +5V_INV，输入 10 uF、输出 2×22 uF、自举 100 nF，电感取原厂固定 5 V 推荐的 4.7 uH；EN 接保护后的辅助输入。U4 TPS7A2033PDBVR 由 5 V 产生 3.3 V，输入 1 uF、输出 2.2 uF，NC 不接。U6 TPS3808G33 监测 3.3 V、CT 有意悬空，开漏输出上拉后加入硬件健康条件。[Diodes AP63205](https://www.diodes.com/assets/Datasheets/AP63200-AP63201-AP63203-AP63205.pdf)、[TI TPS7A20](https://www.ti.com/lit/ds/symlink/tps7a20.pdf)、[TI TPS3808](https://www.ti.com/lit/ds/symlink/tps3808.pdf)

U5 TPS2553 EN 直接由 5 V 供给，与 ENABLE 无关。ILIM=49.9 kΩ，按原厂上下限公式、暂不计电阻误差，约 0.475~0.582 A；0.5 A 是分支负载预算，并不是精确动作门限。J7 单独给 controller 供 5 V/GND，仅选择一块 inverter 的输出，不并联两路。CTRL_PWR_FLT_N 只留本地测试点，未擅自增加外部 MCU 引脚。[TI TPS2553-Q1](https://www.ti.com/lit/ds/symlink/tps2553-q1.pdf)

辅助输入保护仍有重要缺口：27.5 V 名义切断不证明快速浪涌时下游 AP63205 的 32 V 工作上限已经满足，须依据适配器和源阻抗、最大浪涌、切断延迟、吸收/钳位及布局协调。此项列为发布前阻断项，不以 ERC 通过替代。

## 采样与保护门限

INA241A1 的两只 REF 接缓冲 1.65 V，输入正端取 SOURCE、负端取 Kelvin GND。该硬件符号下正电流定义为 SOURCE→GND；若软件按相线向外为正，应统一标定符号。本轮不实现软件。低端分流存在导通状态盲区，不能保证全部开关状态下的短路都被这三路检测覆盖。[TI INA241A](https://www.ti.com/lit/ds/symlink/ina241a.pdf)

| 项目 | 名义实现 | 需要另计的误差/约束 |
| --- | --- | --- |
| 电流输出 | 1.65 V + I×0.05 V/A | 分流±1%、放大器、偏置、温漂和采样盲区 |
| 电流窗口 | 低参考 10k/(39k+1.8k+10k)×3.3=0.649606 V；高参考对称为 2.650394 V | 对应 ±20.008 A，近似已定 ±20 A；参考随本地 3.3 V 变化，不是独立精密基准 |
| 电压比例 | (240k+240k+10k):10k，50:1，分压电阻目标 0.1% | 原厂阻值/额定与 PCB 漏电；上方两只用 0805 分担工作电压 |
| 硬件母线过压 | 20k/13k 得 1.30 V，与本地 V_DC 比较，对应 65 V 名义值 | 3.3 V 误差、分压、运放/比较器偏置和动态延迟；不能保证实际动作点恰为 65.000 V |
| 12 V 驱动轨欠压 | 76.1k/10k 与 1.30 V 比较，名义 11.193 V | 不是母线软件欠压门限；它与转换器 PG 一起参与健康判定 |
| 电压 RC | 母线 100 pF 与约 9.8 kΩ，τ≈0.98 us；相电压 1 nF，τ≈9.8 us | 有源缓冲建立、控制采样和 PWM 成分需核对 |
| 模拟输出负载隔离 | 七路放大输出各串 47 Ω，controller 侧另有 100 Ω/1 nF | 本地保护比较在 47 Ω 前；线缆与 ADC 电容/失电注入仍需验证，不宣称具备外部过压保护 |
| NTC | J8 外接 10 kΩ，板上 10 kΩ 上拉和 10 nF | B 值/型号、安装和开短路判据未定；不接时趋近 3.3 V |

四颗 TLV3202 共八路：六路正负电流窗口、一路母线过压、一路 12 V 欠压。每个输出独立送入逻辑门，推挽输出没有并接。设计为健康输出高，越界输出低；Rev A 不额外加比较器迟滞，首个事件即锁存，噪声及复位边界需验证。

## 故障优先逻辑及复位

五颗 74LVC08A 提供 20 个 AND，使用 19 个：十级健康汇总、复位请求、无锁存条件、总许可及六路 PWM 门；一个未用门输入接地、输出 NC。另用一颗 74LVC00A，两个有效门用于 ENABLE 反相与 FAULT_ACTIVE，另两个输入接地、输出 NC。逻辑门数量比旧的“六路封锁至少两颗”增加，因为本稿已把供电/故障汇总与复位一并画出。

HEALTH_ALL 汇总八个比较器、3.3 V 监控、12 V PG 和辅助 eFuse FLT。U28A 74LVC74 的 **/R 固定高，/S=HEALTH_ALL，D=0**；因此供电有效范围内不会把 /R 与 /S 同时拉低。故障使 /S 低，异步置位 Q=FAULT_LATCH；/Q 为 NO_LATCH。

RESET_REQUEST=HEALTH_ALL AND NOT ENABLE，经 10 kΩ/10 nF 送时钟，名义 RC=100 us。74LVC74A Rev 13 明确输入具有施密特特性，允许较慢输入边沿；该延迟使故障释放先于复位上升沿，避免将同一无延迟组合边沿同时当作异步释放和时钟。它仍需要实际 RC、公差、阈值和恢复时间验证，不能称为已测得 100 us 复位时间。[Nexperia 74LVC74A](https://assets.nexperia.com/documents/data-sheet/74LVC74A.pdf)

DRIVE_PERMIT=HEALTH_ALL AND NO_LATCH AND ENABLE。健康条件在锁存之外直接参与许可，故障关断不等待 MCU，也不等待复位 RC。所有六路 HIN/LIN 均与许可相与，功率板原始 PWM、ENABLE、BRAKE 均有本地下拉，驱动输入另外相对各自 SOURCE 下拉。

| 条件 | 结果 |
| --- | --- |
| 任一活动故障或供电异常 | 六路封锁，置位锁存；ENABLE 不能覆盖 |
| 故障消失，ENABLE 仍高 | 保持锁存，禁止自动恢复 |
| 已健康且 ENABLE 拉低并保持足够时间 | 允许延迟时钟把 Q 清零，驱动仍因 ENABLE 低而封锁 |
| 再次拉高 ENABLE | 健康且无锁存时才允许 PWM |
| 电源恢复但 ENABLE 残留高 | 无有效清锁存边沿，不直接恢复运行 |

初稿要求故障消除后 ENABLE 低保持至少 1 ms，作为验证前的保守接口起点；短暂故障恰在复位过程中发生时，时钟电容可能未充分放低，电路会保持锁存，需要在确认安全时重新进行禁能复位周期。此行为应在后续时序/固件接口审核中明确。没有新增外部 RESET_N 或 MCU 引脚。

FAULT_ACTIVE=NAND(HEALTH_ALL,NO_LATCH)，通过 onsemi MMBT3904LT1G 的基极 10 kΩ 驱动开集电极 FAULT_N，基射极 100 kΩ 默认关。输出功能兼容既有开漏接收接口，controller 上拉约需灌 0.70 mA。**功率板完全失电时输出晶体管不保证拉低，不能把 FAULT_N 高当作板已上电或线缆完整的证明。** 驱动 UVLO、本地下拉和逻辑许可负责自身关断。[onsemi MMBT3904L](https://www.onsemi.com/pdf/datasheet/mmbt3904lt1-d.pdf)

## 未定项与库边界

| 位置 | 待完成事项 |
| --- | --- |
| F1/F2、D1/D2 | 熔断器 DC 分断能力/I²t；D1 新候选 STPS40150CG-TR 的国内立创物料、并流/损耗/散热；D2 SMCJ60CA 候选的原厂资料和脉冲能量。D2 默认 DNP，不能把目录 96.8 V 钳位当成给 100 V 电容留有足够裕量 |
| 辅助入口 | 实际适配器容差/浪涌、eFuse 动态切断、AP63205 最大输入协调及板间压降；目前不宣称车规浪涌能力 |
| L1/L2、普通小阻容 | 完整国巨料号及立创 C 编号、偏压有效容量、频率/温度、容差/功率、具体电感尺寸/焊盘和热；两只电感不是只按 4.7 uH 就可采购 |
| Q1~Q7、RS1~RS3 | TO-263 漏极铜区分离、热态损耗、开关/制动能量、分流温升与故障脉冲；12 V 最差角点的栅压 |
| 保护动态 | 分流盲区、比较器响应、串级逻辑/驱动总关断时间、RC 复位恢复、噪声及故障期间电源完整性；没有做故障注入或 SPICE 开关瞬态验证 |
| J1~J8、SW1、NTC | 完整连接器/按键/热敏料号、额定与封装、防反插、FFC 接触面及脚序方向、NTC 安装 |
| 板间接口 | 失电模拟注入和数字反灌、ESD/浪涌、controller/inverter 两路独立 3.3 V 的误差；各参考域与后续串联系统的隔离方案 |
| 输出 | 直接电机端还是本板集成 LC、阻尼和模式选择，交流源电压采样位置；本稿暂为原始桥输出 |

公共库没有修改。UCC27517、母线电解和国巨旁路已在当前公共库找到 reviewed 记录，本稿引用实际符号/封装，不继续声称它们尚无库。IRFS4227、MMBT3904 和 D1 使用工程专用 `InverterLocal.kicad_sym`：标为 project_draft，不冒充共享库 reviewed 物料。IRFS 的引脚形状复用原同脚序 MOS 图形，封装明确换 TO-263；D1 用 A1/K/A2 三脚并核对 ST 原厂图；小信号管按 B1/E2/C3 核对。公共库后续入库由用户安排，项目草稿不能代替该流程。

KiCad 官方符号/封装复用遵守其 [库许可](https://www.kicad.org/libraries/license/)（CC BY-SA 4.0 及设计使用例外），来源与哈希见 [library_sources.json](review/library_sources.json)。共享库的原始来源记录仍以 `D:/workspace/kicad_library/docs/THIRD_PARTY.md` 为准。进入 PCB 时须修正其 3D 模型项目相对路径，并审查尚为空的 13 个连接器/保险/电感/按键封装。

## 已执行的检查

KiCad 10.0.7 加载完整工程并导出十三页 PDF、原生 XML 网表；默认 ERC 为 **0 错误、0 警告**，未新增排除项。独立脚本基于实际导出网表检查全部显式引脚网络、214 个实际位号和 BOM、桥臂回流/自举、真实封装脚序、供电关键接法、比较器极性、两路 controller 端口脚序；8192 种供电/故障/使能/锁存组合、许可开关下共 128 种 PWM 图样均通过。布尔检查只代表供电有效域的逻辑，不代表断电瞬态、模拟门限、功率/热或物理保护已经验证。

在本目录复查：

```powershell
& 'C:/Program Files/KiCad/10.0/bin/kicad-cli.exe' sch export netlist inverter.kicad_sch --format kicadxml -o review/inverter.net.xml
& 'C:/Program Files/KiCad/10.0/bin/kicad-cli.exe' sch export netlist ../../controller/hardware/controller.kicad_sch --format kicadxml -o review/controller_reference.net.xml
python tools/verify_inverter.py
& 'C:/Program Files/KiCad/10.0/bin/kicad-cli.exe' sch erc inverter.kicad_sch -o review/erc.rpt --exit-code-violations
& 'C:/Program Files/KiCad/10.0/bin/kicad-cli.exe' sch export pdf inverter.kicad_sch -o review/inverter.pdf
```

`tools/build_inverter.py` 是初稿的创建记录。后续以人工修改后的原生 KiCad 文件为准，不未经审查重跑覆盖；修改后重新导出网表/BOM/PDF并核对。
