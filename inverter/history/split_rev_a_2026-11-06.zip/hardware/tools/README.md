# 原理图辅助工具

本目录用于建立和核对 inverter Rev A KiCad 原理图。`schematic_common.py` 为创建器的图形/文件格式辅助代码；不是电路定义。`build_inverter.py` 是本轮初稿的可追踪创建记录，不应在人工修改原生 KiCad 文件后未经审查重跑覆盖。

后续以 KiCad 原生文件为准。`verify_inverter.py` 读取 KiCad 导出的网表进行独立连线和保护逻辑核对；静态检查不能替代瞬态、热和实物验证。
