"""Independent checks of the actual KiCad XML netlist, not the authoring objects."""
from pathlib import Path
from collections import defaultdict
import csv
import json
import math
import xml.etree.ElementTree as ET

B=Path(__file__).resolve().parents[1]
tree=ET.parse(B/'review/inverter.net.xml').getroot()
components={c.attrib['ref']:c for c in tree.findall('./components/comp')}
nets={};members={}
for net in tree.findall('./nets/net'):
    name=net.attrib['name']; nodes={(x.attrib['ref'],x.attrib['pin']) for x in net.findall('node')}
    members[name]=nodes
    for node in nodes:
        assert node not in nets
        nets[node]=name
def at(ref,pin):return nets.get((ref,str(pin)))
def val(ref):return components[ref].findtext('value')
def end(ref,pin,net):assert at(ref,pin)==net, f'{ref}.{pin}: {at(ref,pin)} != {net}'
def nc(ref,pin):
    net=at(ref,pin)
    assert net is None or (net.startswith('unconnected-') and len(members[net])==1), f'{ref}.{pin} is not NC: {net}'
def links(a,b,value,prefix='R'):
    return [ref for ref in components if ref.startswith(prefix) and val(ref)==value and {at(ref,1),at(ref,2)}=={a,b}]
def link(a,b,value,prefix='R'):
    found=links(a,b,value,prefix);assert len(found)==1, (a,b,value,found)
    return found[0]
checks=[]
manifest=json.loads((B/'review/design_manifest.json').read_text(encoding='utf-8'))
assert len(tree.findall('./design/sheet'))==13
assert len(components)==manifest['component_count']==214
bom=list(csv.DictReader((B/'review/bom.csv').open(encoding='utf-8-sig')))
bomref={r['Reference']:r for r in bom};assert set(bomref)==set(components)
for row in csv.DictReader((B/'review/expected_pin_nets.csv').open(encoding='utf-8-sig')):end(row['Reference'],row['Pin'],row['Net'])
checks.append('13 native KiCad sheets / 214 unique component records; all explicit author pin-net assertions and BOM references match KiCad export.')

# Shared controller contract is written explicitly, independent of the generator manifest.
port={1:'PWM_UH_IN',2:'PWM_UL_IN',3:'GND',4:'PWM_VH_IN',5:'PWM_VL_IN',6:'GND',7:'PWM_WH_IN',8:'PWM_WL_IN',9:'GND',10:'ENABLE_IN',11:'FAULT_N',12:None,13:'GND',14:'I_U_PORT',15:'I_V_PORT',16:'I_W_PORT',17:'GND',18:'V_DC_PORT',19:'V_U_PORT',20:'V_V_PORT',21:'GND',22:'V_W_PORT',23:'TEMP_NTC',24:None}
for pin,net in port.items():
    if net is None:nc('J1',pin)
    else:end('J1',pin,net)
ctrl=ET.parse(B/'review/controller_reference.net.xml').getroot();cn={}
for net in ctrl.findall('./nets/net'):
    for v in net.findall('node'):cn[v.attrib['ref'],int(v.attrib['pin'])]=net.attrib['name']
for j,k in [('J2',1),('J4',2)]:
    for pin,net in port.items():
        if net is None:assert cn.get((j,pin),'unconnected-').startswith('unconnected-')
        else:
            target='GND' if net=='GND' else f'INV{k}_'+net.removesuffix('_IN').removesuffix('_PORT')+'_PORT'
            assert cn.get((j,pin))==target,(j,pin,cn.get((j,pin)),target)
end('J7',1,'+5V_CTRL_OUT');end('J7',2,'GND')
end('J6',1,'BRAKE_IN');end('J6',2,'GND')
end('J5',1,'VBUS');end('J5',2,'BR_SW')
checks.append('Inverter J1 all 24 contacts match both current controller inverter ports; six ground contacts and reserved 12/24 retained. Brake and 5 V are separate connectors.')
for net in ['I_U','I_V','I_W','V_DC','V_U','V_V','V_W']:link(net,net+'_PORT','47')
checks.append('All seven amplified analog outputs have local 47-ohm cable/ADC load isolators; current/bus trip sensing stays on the local side of each resistor.')

# Actual package pins and shunt return paths.
for ph,driver,high,low,rs,amp in [('U','U7','Q1','Q2','RS1','U10'),('V','U8','Q3','Q4','RS2','U11'),('W','U9','Q5','Q6','RS3','U12')]:
    source=ph+'_SOURCE';phase=ph+'_PHASE'
    end(high,2,'VBUS');end(high,3,phase);end(high,1,ph+'_GATE_H')
    end(low,2,phase);end(low,3,source);end(low,1,ph+'_GATE_L')
    end(rs,1,source);end(rs,2,'GND');assert source!='GND' and source!=phase
    for pin,net in {1:ph+'_HIN',2:ph+'_LIN',3:source,4:ph+'_LO',5:'+12V_DRV',6:phase,7:ph+'_HO',8:ph+'_BOOT'}.items():end(driver,pin,net)
    link(ph+'_HO',ph+'_GATE_H','15');link(ph+'_LO',ph+'_GATE_L','15')
    link(ph+'_GATE_H',phase,'10k');link(ph+'_GATE_L',source,'10k')
    link(ph+'_HIN',source,'10k');link(ph+'_LIN',source,'10k')
    link(ph+'_BOOT',phase,'2.2u','C');link(ph+'_BOOT',phase,'100n','C')
    link('+12V_DRV',source,'4.7u','C');link('+12V_DRV',source,'100n','C')
    for pin,net in {1:'GND',2:'GND',3:'VBIAS_1V65',4:'GND',5:'I_'+ph,6:'+3V3_INV',7:'VBIAS_1V65',8:source}.items():end(amp,pin,net)
    # No shared power-ground pin accidentally landed on a source node.
    allowed_ref={driver,low,rs,amp}
    for ref,pin in members[source]:
        assert ref in allowed_ref or ref.startswith(('C','R','TP')), (ph,ref,pin)
for ref in ['Q1','Q2','Q3','Q4','Q5','Q6','Q7']:
    assert components[ref].findtext('footprint')=='Package_TO_SOT_SMD:TO-263-3_TabPin2'
end('Q7',1,'BR_GATE');end('Q7',2,'BR_SW');end('Q7',3,'GND')
for pin,net in {1:'+12V_DRV',2:'GND',3:'BRAKE_IN',4:'GND',5:'BR_DRV'}.items():end('U29',pin,net)
link('BRAKE_IN','GND','10k');link('BR_DRV','BR_GATE','15');link('BR_GATE','GND','10k')
checks.append('All seven IRFS G1/D2/S3 maps and TO-263 tab-2 footprints checked. Every driver COM, LO reference, bootstrap and Kelvin input is on its own correct source/phase node; no direct shunt bypass.')
checks.append('Brake driver is a separate UCC27517 stage with IN- low and no bridge ENABLE/FAULT gating; BR+/BR_SW topology checked.')

# Auxiliary application circuits, including subtle ground/sense pins.
for pin,net in {1:'AUX_FUSED',2:'AUX_FUSED',3:'AUX_UV_DIV',5:'AUX_OV_DIV',6:'AUX_MODE',7:'AUX_SHDN_N',8:'EFUSE_RTN',9:'GND',11:'AUX_ILIM',12:'AUX_DVDT',14:'AUX_FLT_N',15:'AUX_PROTECTED',16:'AUX_PROTECTED',17:'EFUSE_RTN'}.items():end('U1',pin,net)
assert at('U1',8)!=at('U1',9)
for pin in [4,10,13]:nc('U1',pin)
for net,value in [('AUX_MODE','402k'),('AUX_ILIM','7.87k')]:link(net,'EFUSE_RTN',value)
link('AUX_DVDT','EFUSE_RTN','22n','C')
for pin,net in {1:'GND',2:'BB_L1',3:'BB_BST1',4:'AUX_PROTECTED',5:'AUX_PROTECTED',6:'AUX_PROTECTED',7:'GND',8:'GND',9:'GND',10:'BB_PG_DLY',11:'BB_VREG',12:'BB_VREG',13:'GND',14:'BB_VREG',15:'DRV_PG_NOM',16:'+12V_DRV',17:'+12V_DRV',18:'GND',19:'BB_BST2',20:'BB_L2',21:'GND'}.items():end('U2',pin,net)
link('BB_BST1','BB_L1','100n','C');link('BB_BST2','BB_L2','100n','C')
assert {at('L1',1),at('L1',2)}=={'BB_L1','BB_L2'}
link('+5V_INV','DRV_PG_NOM','10k');link('DRV_PG_NOM','DRV_PG_LOGIC','10k');link('DRV_PG_LOGIC','GND','20k')
for pin,net in {1:'+5V_INV',2:'AUX_PROTECTED',3:'AUX_PROTECTED',4:'GND',5:'BUCK_SW',6:'BUCK_BST'}.items():end('U3',pin,net)
assert {at('L2',1),at('L2',2)}=={'BUCK_SW','+5V_INV'}
link('BUCK_BST','BUCK_SW','100n','C')
for pin,net in {1:'+5V_INV',2:'GND',3:'+5V_INV',5:'+3V3_INV'}.items():end('U4',pin,net)
nc('U4',4)
for pin,net in {1:'+5V_INV',2:'GND',3:'+5V_INV',4:'CTRL_PWR_FLT_N',5:'CTRL_ILIM',6:'+5V_CTRL_OUT'}.items():end('U5',pin,net)
link('CTRL_ILIM','GND','49.9k')
for pin,net in {1:'LOGIC_POWER_OK',2:'GND',3:'+3V3_INV',5:'+3V3_INV',6:'+3V3_INV'}.items():end('U6',pin,net)
nc('U6',4)
checks.append('eFuse RTN/EP isolated from GND and MODE=402k; TPS55165 VREG/VREG_Q/VOS_FB, switch nodes/boots, 5 V PG pull-up/divider, AP63205 fixed-output feedback, LDO and independent controller switch checked.')

# Comparator polarity and latch truth table read directly from the pin-net maps.
healthy=[]
for idx,ph in enumerate('UVW',18):
    ref='U'+str(idx)
    for pin,net in {1:f'OC_{ph}_HIGH_OK',2:'I_'+ph,3:'OC_HIGH_REF',5:'I_'+ph,6:'OC_LOW_REF',7:f'OC_{ph}_LOW_OK',4:'GND',8:'+3V3_INV'}.items():end(ref,pin,net)
    healthy.extend([f'OC_{ph}_HIGH_OK',f'OC_{ph}_LOW_OK'])
for pin,net in {1:'BUS_OV_OK',2:'V_DC',3:'OV_REF_1V30',5:'DRV_UV_DIV',6:'OV_REF_1V30',7:'DRV_UV_OK',4:'GND',8:'+3V3_INV'}.items():end('U21',pin,net)
healthy += ['BUS_OV_OK','DRV_UV_OK','LOGIC_POWER_OK','DRV_PG_LOGIC','AUX_FLT_N']
for pin,net in {1:'+3V3_INV',2:'GND',3:'RESET_CLK',4:'HEALTH_ALL',5:'FAULT_LATCH',6:'NO_LATCH',7:'GND',14:'+3V3_INV',10:'+3V3_INV',11:'GND',12:'GND',13:'+3V3_INV'}.items():end('U28',pin,net)
nc('U28',8);nc('U28',9)
link('RESET_REQUEST','RESET_CLK','10k');link('RESET_CLK','GND','10n','C')
link('FAULT_ACTIVE','FAULT_BASE','10k');link('FAULT_BASE','GND','100k')
end('Q8',1,'FAULT_BASE');end('Q8',2,'GND');end('Q8',3,'FAULT_N')
pin_units=[(1,2,3),(4,5,6),(9,10,8),(12,13,11)]
gates=[]
for ref,kind in [(f'U{i}','AND') for i in range(22,27)]+[('U27','NAND')]:
    end(ref,7,'GND');end(ref,14,'+3V3_INV')
    for a,b,y in pin_units:
        if at(ref,y) is None or at(ref,y).startswith('unconnected-'):continue
        gates.append((at(ref,a),at(ref,b),at(ref,y),kind))
def evaluate(inputs):
    v={'GND':False,'+3V3_INV':True}|inputs
    for _ in range(len(gates)+1):
        progress=False
        for a,b,y,kind in gates:
            if y not in v and a in v and b in v:
                v[y]=(v[a] and v[b]) if kind=='AND' else not(v[a] and v[b]);progress=True
        if not progress:break
    return v
truth_cases=0
for mask in range(1<<len(healthy)):
    inputs={net:bool(mask&(1<<i)) for i,net in enumerate(healthy)}
    for en in [False,True]:
        for latched in [False,True]:
            v=evaluate(inputs|{'ENABLE_IN':en,'NO_LATCH':not latched}|{f'PWM_{s}_IN':True for s in ['UH','UL','VH','VL','WH','WL']})
            h=all(inputs.values())
            assert v['HEALTH_ALL']==h
            assert v['RESET_REQUEST']==(h and not en)
            assert v['FAULT_ACTIVE']==(not(h and not latched))
            permit=h and en and not latched
            assert v['DRIVE_PERMIT']==permit
            for p in 'UVW':assert v[p+'_HIN']==permit and v[p+'_LIN']==permit
            truth_cases+=1
for permit_enable in [False,True]:
    for mask in range(64):
        raw={f'PWM_{p}_IN':bool(mask&(1<<i)) for i,p in enumerate(['UH','UL','VH','VL','WH','WL'])}
        v=evaluate({s:True for s in healthy}|{'ENABLE_IN':permit_enable,'NO_LATCH':True}|raw)
        for i,p in enumerate(['UH','UL','VH','VL','WH','WL']):assert v[p[0]+('_HIN' if p[1]=='H' else '_LIN')]==(permit_enable and bool(mask&(1<<i)))
checks.append(f'Comparator input polarity checked. {truth_cases} actual-netlist logic cases passed: any active fault/power loss blocks every driver input; latched fault cannot restart with ENABLE high; reset only requested while all healthy and disabled.')
checks.append('All 64 raw PWM patterns tested with permit on/off. DFF /R fixed high, /S=HEALTH_ALL, D=0, delayed clock verified; illegal simultaneous asynchronous assertion structurally absent within the powered logic domain.')

# Divider values and buffer feedback are checked against the network, not comments.
for sig,raw,ref in [('V_DC','VBUS','U14'),('V_U','U_PHASE','U15'),('V_V','V_PHASE','U16'),('V_W','W_PHASE','U17')]:
    link(raw,sig+'_DIV1','240k');link(sig+'_DIV1',sig+'_DIV2','240k');link(sig+'_DIV2',sig+'_DIV','10k');link(sig+'_DIV','GND','10k')
    end(ref,1,sig+'_DIV');end(ref,3,sig);end(ref,4,sig);end(ref,2,'GND');end(ref,5,'+3V3_INV')
link('+3V3_INV','VBIAS_DIV','10k');link('VBIAS_DIV','GND','10k')
end('U13',1,'VBIAS_DIV');end('U13',3,'VBIAS_1V65');end('U13',4,'VBIAS_1V65')
for a,b,value in [('+3V3_INV','OC_LO_MID','39k'),('OC_LO_MID','OC_LOW_REF','1.8k'),('OC_LOW_REF','GND','10k'),('+3V3_INV','OC_HIGH_REF','10k'),('OC_HIGH_REF','OC_HI_MID','1.8k'),('OC_HI_MID','GND','39k'),('+3V3_INV','OV_REF_1V30','20k'),('OV_REF_1V30','GND','13k'),('+12V_DRV','DRV_UV_DIV','76.1k'),('DRV_UV_DIV','GND','10k')]:link(a,b,value)
for row in bom:
    if row['Reference'].startswith(('R','C')) and not row['Reference'].startswith('RS') and row['MPN'] not in ['EKYB101ELL221MK25S']:
        assert row['Manufacturer']=='YAGEO',row['Reference']
bulk=[r for r in bom if r['MPN']=='EKYB101ELL221MK25S'];bypass=[r for r in bom if r['MPN']=='CS1210KKX7R0BB225']
assert len(bulk)==2 and len(bypass)==2
assert bomref['D2']['DNP']=='yes'
for pin in [1,3]:end('D1',pin,'DC_FUSED')
end('D1',2,'VBUS')
assert not [r for r in bom if r['Reference'].startswith('K') or 'precharge' in r['Value'].lower()]
checks.append('Four 50:1 dividers/followers, 1.65 V bias, nominal +/-20.008 A / 65 V / 11.193 V divider values, 2x220uF and 2x2.2uF checked; ordinary small R/C are YAGEO. No precharge relay or dedicated bus bleeder added.')
values={'oc_low_v':3.3*10000/50800,'oc_high_v':3.3*40800/50800,'oc_abs_a':(3.3*40800/50800-1.65)/.05,
        'bus_ov_nominal_v':3.3*13000/33000*50,'driver_uv_nominal_v':3.3*13000/33000*8.61,
        'aux_uv_rising_nominal_v':1.19*(1+78700/10000),'aux_ov_nominal_v':1.19*(1+221000/10000),
        'aux_ilim_approx_a':11800/7870,'aux_ramp_24v_nominal_ms':8000*24*22e-9*1000,
        'ctrl_ilim_min_a_nominal_r':25230/(49.9**1.016)/1000,'ctrl_ilim_max_a_nominal_r':22980/(49.9**.94)/1000,
        'bus_stored_energy_at_60v_j':.5*440e-6*60**2,'bus_stored_energy_at_65v_j':.5*440e-6*65**2,
        'reset_rc_us':10000*10e-9*1e6,'pg_logic_high_nominal_v':5*20000/(10000+10000+20000)}
report={'result':'PASS','sheets':13,'components':214,'logic_cases':truth_cases,'pwm_pattern_cases':128,'checks':checks,'nominal_calculations':values,
        'limitations':['Static connectivity and powered-domain Boolean logic only; no SPICE switching, gate waveform, timing/SOA/thermal or hardware test.',
        'RC reset edge requires analog recovery/pulse and noise validation; brief faults during reset may remain safely latched until another deliberate disable cycle.',
        'Main input diode/TVS/fuse, exact inductors/passives, connectors, gate-drive corner margin and isolation/source domain remain release blockers.']}
(B/'review/connectivity_check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(B/'review/connectivity_check.txt').write_text('PASS\n\n'+'\n'.join('- '+x for x in checks)+'\n\nNOMINAL CALCULATIONS\n'+json.dumps(values,indent=2)+'\n\nLIMITATIONS\n'+'\n'.join(report['limitations'])+'\n',encoding='utf-8')
print(json.dumps({k:report[k] for k in ['result','sheets','components','logic_cases','pwm_pattern_cases']}))
