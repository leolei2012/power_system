# Rev D MCU子板与功率底板

2026-11-06完成 **STM32G431RBT6控制子板＋功率底板** 两套原理图。采用低成本共地、非隔离、可拔插结构，每套控制一路三相桥和一路制动；PFC电源板本阶段仍不绘制。

| 工程 | 当前交付 |
| --- | --- |
| [controller子板](../controller/hardware/g431_core/README.md) | 8页、140个位号、14项DNP；[原生工程](../controller/hardware/g431_core/controller.kicad_pro)、[PDF](../controller/hardware/g431_core/review/controller.pdf) |
| [inverter底板](../inverter/hardware/README.md) | 16页、219个位号、3项DNP；[原生工程](../inverter/hardware/inverter.kicad_pro)、[PDF](../inverter/hardware/review/revd_power.pdf) |

两工程ERC均为0错误、0警告；40针、64个MCU封装脚及16384组静态保护逻辑检查通过，见 [系统报告](../controller/hardware/g431_core/review/system_check.txt)。两板PCB均未设计；底板60×60 mm为目标，层数、孔位、安装高度及接插件朝向仍待实际布局。

## 电路分工

| controller子板 | inverter功率底板 |
| --- | --- |
| STM32G431、去耦、HSE候选、复位、BOOT0 | MOS、栅极驱动、自举及局部回流 |
| 八路ADC末端100 Ω/1 nF及VDDA/VREF | 三路分流/INA、四路电压和NTC前端 |
| SWD、TTL、两路ABZ、两路SPI、可选DNP CAN | 比较器、故障锁存、六路PWM门控、制动功率支路 |
| 四个GPIO LED、本地3.3 V/监控器、接口限流/钳位 | 母线、12～24 V辅助输入、12 V/5 V/底板3.3 V及电源灯 |

底板硬件保护独立关断栅极驱动，功率电流不经过子板排针。PWM、ENABLE、BRAKE及CTRL_READY在底板有失联下拉。底板未就绪时`BASE_READY_MCU`由子板下拉保持低；`FAULT_N_MCU`有本地上拉，高电平不能单独证明底板已上电或健康。

## 供电与保护

底板J101/1、3的`+5V_INV`对应子板`+5V_CORE_IN`，由TLV76733DRVR产生本地`+3V3_MCU`，3.3 V总负载预算100 mA。底板`+3V3_INV`与它不并联。J102/17、18的`+5V_SENSOR`来自底板U5限流输出，与子板5 V输入保持分开；外设供电连接默认DNP。

`MCU_RESET_N`只在子板连接监控器、SWD和按键，不经过板间接口；缓冲后的`CTRL_READY`才送到底板。它仅表示本地供电/复位允许，运行使能仍由ENABLE管理。

八路ADC入口为 **360 Ω（R201～R208）→BAT54S钳位→100 Ω/1 nF末端RC→MCU**，两级电阻名义合计460 Ω，外部源阻抗另计。钳位电流不流经末端100 Ω，因此故障注入限流只能按360 Ω计算。`BASE_READY`、`FAULT_N`各经1 kΩ和钳位后，分别成为PC13/p2的`BASE_READY_MCU`、PB12/p34的`FAULT_N_MCU`；另外6个GPIO保持NC，见 [64脚表](../controller/hardware/g431_core/STM32G431RBT6_pin_plan.csv)。

本地吸收通道的短时总正向注入预算为50 mA，合计包含八路模拟和两路状态输入，不能理解为每路50 mA或持续耐受能力。供电细节及验证条件见 [本地供电分析](../controller/hardware/g431_core/core_supply_design.md)。

## 40针合同

两组 **2×10、2.54 mm直接排针/排母**，不使用IDC镜像排线。所有非电源针同位号1:1连接；仅J101/1、3的供电在两工程中使用不同网名。总计 **15地＋4电源＋19信号＋2NC＝40针**。

| 针号 | J101：控制/状态 | J102：采样/传感器电源 |
| --- | --- | --- |
| 1 | 底板+5V_INV → 子板+5V_CORE_IN | I_U_PORT |
| 2 | GND | GND |
| 3 | 底板+5V_INV → 子板+5V_CORE_IN | I_V_PORT |
| 4 | GND | GND |
| 5 | PWM_UH_IN | I_W_PORT |
| 6 | PWM_UL_IN | GND |
| 7 | GND | V_DC_PORT |
| 8 | PWM_VH_IN | GND |
| 9 | PWM_VL_IN | V_U_PORT |
| 10 | GND | GND |
| 11 | PWM_WH_IN | V_V_PORT |
| 12 | PWM_WL_IN | GND |
| 13 | GND | V_W_PORT |
| 14 | ENABLE_IN | GND |
| 15 | BRAKE_IN | TEMP_NTC |
| 16 | GND | GND |
| 17 | CTRL_READY | +5V_SENSOR |
| 18 | BASE_READY | +5V_SENSOR |
| 19 | FAULT_N | NC |
| 20 | GND | NC |

PWM、ENABLE、BRAKE、CTRL_READY由子板到达底板；BASE_READY、FAULT_N及八路模拟量由底板返回。19条功能信号为6路PWM、使能/制动2路、就绪/故障3路和采样8路。机器定义见 [针位合同](daughterboard_pin_contract.json)。原始NRST和两侧3.3 V不占板间针。

## 维修与交付边界

可拔插结构便于复用仍完好的控制子板，**不提供电气隔离，也不保证炸管后MCU存活**。本版未证明带电插拔能力；装拆按断电维护处理。ERC和静态逻辑通过不替代供电瞬态、保护总延迟、采样窗口、热及实际故障验证。

旧十八页Rev C集成版及其未完成的60 mm六层PCB已存入 [历史目录](../inverter/history/integrated_rev_c_60x60/)，[分拆前ZIP](../inverter/history/integrated_60x60_rev_c_before_mcu_split_2026-11-06.zip)继续保留。旧313位号、七个NC及布线报告仅适用于合板历史；更早的 [LKS controller](../controller/hardware/controller.kicad_sch)也不能直接用于本次子板。
