# power_system

低压电力电子实验平台。当前 **Rev D 可拔插 STM32G431RBT6 控制子板＋功率底板原理图已完成**，采用共地、非隔离连接；每套控制一路三相桥和一路制动。PFC 电源板暂不绘制。板卡分工、供电和40针定义见 [双板设计说明](docs/controller_daughterboard.md)。

| 当前工程 | 原理图与检查 |
| --- | --- |
| [controller 控制子板](controller/hardware/g431_core/README.md) | 8页，140个位号、14项DNP；[KiCad](controller/hardware/g431_core/controller.kicad_pro)、[PDF](controller/hardware/g431_core/review/controller.pdf) |
| [inverter 功率底板](inverter/hardware/README.md) | 16页，219个位号、3项DNP；[KiCad](inverter/hardware/inverter.kicad_pro)、[PDF](inverter/hardware/review/revd_power.pdf) |

两工程的已导出 ERC 均为 **0错误、0警告**；40个物理排针、跨板信号与静态保护逻辑检查通过。检查入口为 [系统核对](controller/hardware/g431_core/review/system_check.txt)、[子板ERC](controller/hardware/g431_core/review/erc.json)和 [底板ERC](inverter/hardware/review/revd_power_erc.json)。这不是PCB或实物验证结论：新底板仍以 **60×60 mm为目标，尚未布局，也没有与Rev D配套的PCB**；子板PCB同样未做。

功率指标沿用12～60 V直流母线、直流输入最大10 A、每相连续10 Arms设计目标及20 kHz桥PWM，保留本地过流/过压保护和外接制动电阻支路。功率母线可接实验直流源或后续自研模块；辅助输入为独立12～24 V。底板提供5 V给子板，子板使用TLV76733DRVR独立产生3.3 V，3.3 V总负载预算100 mA；两板3.3 V和原始NRST均不跨接。

子板保留八路ADC、两路ABZ、两路SPI、TTL、SWD、四个GPIO指示灯及可选DNP的CAN/HSE。两组2×10、2.54 mm直接排针共40针，包含19信号、15地、4电源和2NC。接口有限流及钳位，短时总正向注入预算50 mA；它仍是非隔离实验硬件，**不保证功率器件损坏后MCU存活**。额定、热、动态保护、插接和实际装配仍待样机验证。

电源板的Boost/Vienna版本及PFC＋LLC仍属后续规划，相关输入、变比和资源可行性不由本次变频器原理图确认。实验链路与长期讨论见 [架构](vfd/docs/architecture.md)和 [路线图](docs/roadmap.md)。当前先用实验直流电源，不把历史市电高压草案套到本板。

## 历史与器件约定

原 [LKS controller](controller/hardware/controller.kicad_sch)保留为历史；新G431工程位于独立的 `controller/hardware/g431_core/`。十八页Rev C集成版及其未完成的60×60 mm六层PCB已移至 [Rev C归档](inverter/history/integrated_rev_c_60x60/)，另有 [分拆前快照](inverter/history/integrated_60x60_rev_c_before_mcu_split_2026-11-06.zip)。旧PCB检查及313位号清单不能作为当前双板的验证或采购依据。

器件统一在立创商城选型，按完整型号、C号和原厂规格书核对。普通小贴片阻容统一YAGEO，分流、电解及稳定性关键电容另行选型。公共库为相邻 `kicad_library`；项目草稿符号/封装不等于公共库已审核或实物已验证。当前已导出 [子板BOM](controller/hardware/g431_core/bom/bom.csv)和 [底板BOM](inverter/hardware/bom/bom.csv)，两项目也各有完整型号待定和公共库待建清单。实际位号/连通依据为 [子板XML](controller/hardware/g431_core/review/controller.net.xml)、[底板XML](inverter/hardware/review/revd_power.net.xml)；359个位号的封装存在及焊盘号覆盖已核对，应用/热/装配仍待验证。

参考资料统一存放于 [reference](reference/README.md)，主要硬件对照为 [ATK-PD6010B](reference/ATK-PD6010B/README.md)。更早的 [Rev A分板](inverter/history/split_rev_a_2026-11-06.zip)和 [200×140 mm PCB0.1](inverter/history/pcb_0_1_200x140_before_60mm_2026-11-06.zip)继续保留历史。
