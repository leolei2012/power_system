# G431 core 本地供电与复位（Rev D，project_draft）

本说明对应 `core_supply.kicad_sch`。它只管理可拔插控制核心的供电、复位和 `CTRL_READY`；功率底板的硬件保护仍在底板本地。公共器件库未修改，新符号仅写入 `CoreProtection.kicad_sym`。

## 已画电路

`+5V_CORE_IN → R301 0.47Ω → TVS/输入电容 → D102 → U101 TLV76733 → +3V3_MCU`。

`+3V3_MCU` 与底板 `+3V3_INV` 不并联，两板共地。D102采用低漏电的硅整流管，阻止核心电容或信号钳位电流回到 5 V 插座；D103从 LDO OUT 接向 IN，旁路 LDO 掉电反压。D101仅处理能量受限的短时正向扰动，R301是阻尼电阻，不是保险丝或浪涌能量额定器件。本页不承担持续24/60 V误接保护，也不代表已通过IEC浪涌或热插拔认证。

原计划的 TPS7A20 不适合直接依靠普通5 V TVS保护：TI给出的推荐输入上限6.0 V、绝对最大6.5 V，低压TVS的脉冲钳位仍可能远高于这个值。实际改为项目库已有的16 V输入TLV76733；MCC SMF6.0A的指定钳位值为10.3 V，给LDO留出额定输入余量。TVS数值仍有指定波形、电流和布局条件，不能外推到任意来源的故障。[TI TPS7A20](https://www.ti.com/lit/ds/symlink/tps7a20.pdf)、[TI TLV767，§6/§9.1.4](https://www.ti.com/lit/ds/symlink/tlv767.pdf)、[MCC原厂表格镜像，p2](https://www.alldatasheet.co.kr/html-pdf/433293/MCC/SMF6.0A/114/2/SMF6.0A.html)。

## 电压、电流及散热预算

入口合同为插座处稳态4.75–5.25 V，不是给功率母线直接使用的宽压输入。本版 `+3V3_MCU` **总预算100 mA持续**，包含MCU、模拟/数字外围、四个LED、可选CAN及外供3.3 V传感器；各传感器接口没有额外独立的100 mA额度。CAN默认DNP。装CAN或较大负载编码器前需要重新核总负载。TLV767的1 A芯片额定值不等于本版插座或核心板额定值。

| 项目 | 本版约束/计算 |
|---|---|
| MCU及启用外设 | 先留60 mA工程预算；并非ST保证的所有外设全开最大值 |
| 四个状态LED | 建议总计≤8 mA，最终按串阻/LED Vf核算 |
| 其余本地逻辑、外供传感器及余量 | 合计落在剩余约32 mA内；装CAN后重新分配 |
| 5 V入口持续供电预留 | 至少120 mA；包括MR分压、LDO地电流和TVS漏电余量 |
| 启动电流 | C305及输入电容充电不受100 mA稳态预算限制；需在底板5 V实物验证启动/插接波形 |

ST数据表中高主频的电流表有温度、执行存储器和外设关闭等条件，不能把某个典型值作为整个核心板最大耗电。[STM32G431RB数据表，电流特性](https://www.st.com/resource/en/datasheet/stm32g431rb.pdf)。

以100 mA负载计算，另计MR分压后R301约掉0.05 V。D102即保守借用其25°C、1 A条件下的1.1 V最大Vf，U101入口仍约为 `4.75−0.05−1.10=3.60 V`。TI给出的DRV封装最大压差1.4 V@1 A，并在§8.3.2说明以导通电阻估算较小电流，100 mA对应约0.14 V；与3.333 V输出上限比较尚有约0.12 V估算余量。该推算不是100 mA/全温度单独生产保证；最低入口、冷态、动态负载和插座压降仍需样机确认。[Diodes S1A原厂数据表](https://www.diodes.com/datasheet/download/S1M.pdf)、[TI TLV767](https://www.ti.com/lit/ds/symlink/tlv767.pdf)。

U101最保守忽略D102压降，损耗上界近似 `(5.25−3.3)×0.1=0.195 W`；TI DRV的JEDEC参考θJA=77.7°C/W，估算升温约15°C。实际需连接EP至地铜并结合底板热源核温，不能把JEDEC参数直接当最终PCB保证。

## 3.3 V钳位注入与稳定性

U104为TL431BIDBZR。R302=3.83 kΩ、R303=10 kΩ均0.1%，名义开启点约为 `2.495×(1+3.83/10)+IREF×3.83k≈3.46 V`。LDO本身不会吸收信号钳位注入电流，U104提供有限的吸收通道。TL431B的参考初始误差、温漂、REF偏流、动态阻抗均会影响实际钳位值；这不是精确的3.450 V故障界限，更不是硬性保证瞬态峰值不超过MCU绝对最大值。需实测脉冲注入时的轨电压、振铃和器件温升。[TI TL431，§6.12/稳定性章节](https://www.ti.com/lit/ds/symlink/tl431.pdf)。

**总正向短时注入工程预算≤50 mA**，不是达到50 mA便自动切断的限流器。接口8路模拟钳位在360 Ω之后、100 Ω之前，因此流进BAT54S及电源轨的限流电阻只有360 Ω。100 Ω仅在ADC支路：正常采样本地RC为 `(360+100)Ω×1 nF=0.46 µs`，外部源阻抗另计；故障注入不能将这两个电阻串算。BASE_READY/FAULT_N两路数字钳位各经1 kΩ，同属这个50 mA总预算。

按全部10路输入均为5.25 V、本地轨取3.25 V、忽略二极管正向压降，且360 Ω及1 kΩ电阻都取1%负容差，合计为：

`8×(5.25−3.25)/(360×0.99) + 2×(5.25−3.25)/(1000×0.99) = 48.93 mA < 50 mA`。

该计算以本地轨不低于3.25 V为前提，不能直接代替断电轨从0 V建立时或轨电压振铃的动态分析；实际正常端口来自3.3 V域。既有50 mA分流器条件和器件型号保持不变；本页不保证60 V持续故障免疫。

C305必须装47 µF±10%/10 V钽电容。它是TL431稳定性设计的一部分，不应仅按标称容量换成会明显直流偏压降容的MLCC。TI稳定性资料要求考虑阴极电压、电流、输出电容及ESR；本设计选在大电容一侧，47 µF的初始最小42.3 µF加本地陶瓷电容，比资料所举>22 µF的保守示例更大，并应结合3.46 V、0.7–50 mA范围复核。资料曲线本身是典型特性，最终稳定性仍须样机验证。TLV767输出电容额定范围1–220 µF，本页的4.7 µF陶瓷加47 µF及MCU分布去耦处在总容量范围内；保留U101旁的陶瓷电容，不能只剩高ESR钽电容。[TI SLVA482A](https://www.ti.com/lit/an/slva482a/slva482a.pdf)、[KEMET T491原厂数据表](https://content.kemet.com/datasheets/KEM_T2005_T491.pdf)。

## 复位及许可

U102复用TPS3808G33DBVR，SENSE/VDD接本地3.3 V，RESET为开漏，R306上拉到本地3.3 V。CT留空，释放延迟典型20 ms。按键、SWD和C81仍在debug页。`MCU_RESET_N`不经过功率底板插座。[TI TPS3808](https://www.ti.com/lit/ds/symlink/tps3808.pdf)。

MR额外检查D102**之前**的5 V节点，R304/R305=1 kΩ/1.1 kΩ。低端4.75 V输入时MR约2.46 V，高于0.7×3.333 V=2.333 V；高端10.3 V TVS指定钳位时MR约5.40 V，低于MR推荐上限6.5 V。

5 V插座断开、核心被信号钳位反向托起时，MR仍通过R305拉低。D102选硅整流管而非普通SS14，是为了避免后者mA级高温漏电抬高这个检测点。即使取S1A在125°C/额定反压下的最大100 µA漏电，以及TPS3808最小70 kΩ内部上拉，MR仍约低于0.2 V，低于0.3×本地VDD低电平门限。该比较覆盖本页漏电来源，未假定所有其它外接电缆都不会额外给5 V入口供电。

U103 SN74LVC1G17DBVR将本地NRST缓冲成高有效`CTRL_READY`。它具有Ioff部分断电特性，核心断电时由底板10 kΩ下拉得到低许可。`CTRL_READY`仅表示本地供电/复位允许，不表示固件自检已完成。固件运行许可仍须由ENABLE/控制状态管理。[TI SN74LVC1G17](https://www.ti.com/lit/ds/symlink/sn74lvc1g17.pdf)。

## 精确器件候选

均为project_draft，未宣称经过样机验证。U101/U102复用公共库已有reviewed组件；新增型号未修改公共库。通用小电阻/陶瓷电容保持YAGEO，普通件具体MPN和直流偏压曲线仍未全部冻结。

| 位号 | 完整型号 | LCSC | 封装/用途 |
|---|---|---|---|
| U101 | TLV76733DRVR，TI | [C2848334](https://www.lcsc.com/product-detail/C2848334.html) | WSON-6+EP，独立3.3 V |
| U102 | TPS3808G33DBVR，TI | [C43698](https://www.lcsc.com/product-detail/C43698.html) | SOT23-6，本地监控 |
| U103 | SN74LVC1G17DBVR，TI | [C7836](https://www.lcsc.com/product-detail/C7836.html) | SOT23-5，CTRL_READY缓冲 |
| U104 | TL431BIDBZR，TI | [C41283](https://www.lcsc.com/product-detail/C41283.html) | SOT23-3，钳位注入吸收 |
| D101 | SMF6.0A-TP，MCC | [C914434](https://www.lcsc.com/product-detail/C914434.html) | SOD123FL，短时输入TVS |
| D102 | S1A-13-F，Diodes | [C150735](https://www.lcsc.com/product-detail/C150735.html) | SMA，低漏电反向阻断 |
| D103 | PMEG2010ER,115，Nexperia | [C82288](https://www.lcsc.com/product-detail/C82288.html) | CFP3/SOD123W，低Vf反压旁路 |
| C305 | T491B476K010AT，KEMET | [C116617](https://www.lcsc.com/product-detail/C116617.html) | B/3528-21，47 µF±10%/10 V；稳定性关键件 |
| R302 | RT0603BRD073K83L，YAGEO | [C861384](https://www.lcsc.com/product-detail/C861384.html) | 3.83 kΩ、0.1%、0603 |
| R303 | RT0603BRD0710KL，YAGEO | [C95204](https://www.lcsc.com/product-detail/C95204.html) | 10 kΩ、0.1%、0603 |

R301=0.47 Ω/0805，已有核对到的YAGEO采购候选为[RL0805FR-070R47L/C705493](https://www.lcsc.com/product-detail/C705493.html)，但本页原生通用电阻字段尚标TBD；不能把它写成已完成公共库物料。C301/C302需25 V、0805、4.7 µF，实际在5.25 V下有效容量至少2.2 µF；C303在3.3 V下同样需保留有效容量。其余100 nF陶瓷电容和R304/R305/R306保持原理图给定值与品牌，精确MPN待普通被动件统一采购时补齐。

## 电气及图面检查

供电页共20个物理器件。通过完整controller top导出的KiCad XML逐条检查51个pin-net映射，U102.4(CT)、U103.1(NC)按原厂规定留空。完整top在本页交付时ERC为0 error / 0 warning；它证明连接及库引用检查通过，不替代上面的电源动态/热/故障实测。

D103使用本机实际存在的`Diode_SMD:Nexperia_CFP3_SOD-123W`。两个焊盘中心±1.4 mm、尺寸1.2×1.2 mm、中心距2.8 mm、内隙1.6 mm，pad1为阴极，与原厂CFP3回流焊land图核对；没有用不存在的`D_SOD-123W`名称规避警告。[PMEG2010ER原厂数据表，p2/p9](https://assets.nexperia.com/documents/data-sheet/PMEG2010ER.pdf)。

检查输出见`review/core_supply_validation.json`，图面预览见`review/core_supply.pdf`。生成脚本`tools/build_core_supply.py`只写本页、本地CoreProtection库和本页expected报告，不会生成其它子页或修改旧inverter。
