# Rev D STM32G431控制子板

本工程是可拔插、共地的STM32G431RBT6控制子板，配套 [inverter功率底板](../../../inverter/hardware/README.md)。**八页原理图已完成，140个位号、14项DNP，ERC为0错误、0警告**。原LKS工程仍在上级hardware目录，未被覆盖。

- [KiCad工程](controller.kicad_pro)、[原理图](controller.kicad_sch)、[八页PDF](review/controller.pdf)
- [64脚表](STM32G431RBT6_pin_plan.csv)、[实际XML](review/controller.net.xml)、[BOM](bom/bom.csv)
- [完整型号待定](bom/selection_pending.csv)、[公共库待建候选](bom/library_intake.csv)
- [ERC](review/erc.json)、[双板系统核对](review/system_check.txt)、[供电分析](core_supply_design.md)
- [两板分工及完整40针定义](../../../docs/controller_daughterboard.md)

## 功能与引脚

子板保留MCU及去耦、ADC末端RC/VDDA/VREF、时钟复位、BOOT0、SWD、TTL、2×ABZ、2×SPI、四个GPIO指示灯和可选经典CAN。CAN整支路默认DNP，HSE及负载电容默认DNP；R100/R107/R113/R119四个传感器5 V连接默认DNP。外部编码器/SPI信号仍为3.3 V单端。

PC13/p2接保护后的`BASE_READY_MCU`，PB12/p34接`FAULT_N_MCU`并用于TIM1 BKIN。六个未分配GPIO为PC14/p3、PC15/p4、PC7/p39、PB3/p56、PB4/p57、PB9/p62，原理图显式NC。四个状态灯对应PC5/p23、PC8/p40、PD2/p55、PB5/p58。

八路模拟信号从J102进入，经R201～R208各360 Ω和BAT54S钳位后，再进原R84～R91各100 Ω/C69～C76各1 nF末端RC。子板两级电阻名义合计460 Ω；钳位注入限流只由前面的360 Ω决定。BASE_READY和FAULT_N分别经1 kΩ及钳位进入MCU；`FAULT_N_MCU`高电平不能单独代表底板健康，须结合`BASE_READY_MCU`。

## 供电与复位

J101/1、3由底板`+5V_INV`送入本板`+5V_CORE_IN`。U101 TLV76733DRVR产生独立`+3V3_MCU`，**3.3 V总负载预算100 mA**，包含已启用的MCU、外围、LED、CAN和外供负载。该数值是本版系统预算，不是LDO芯片额定值。`+5V_SENSOR`由底板U5经J102/17、18另行供给，不能与`+5V_CORE_IN`短接。

本地监控器、SWD与按键共用`MCU_RESET_N`，原始NRST不出子板。缓冲后的`CTRL_READY`发往底板，仅表示本地供电/复位允许，不等于固件自检完成；运行仍由ENABLE管理。两板3.3 V不并联。

输入钳位与本地吸收通道按 **短时总正向注入≤50 mA** 做工程预算，包含八路模拟和两路状态输入；它不是自动切断限流器或持续故障耐受承诺。共地设计不保证功率级损坏后MCU存活，具体电源/稳定性计算见供电分析。

## 交付状态

40个物理针位、完整64脚、跨板供电别名、16384组静态保护逻辑检查已通过。PCB、动态故障、采样时序、供电启动/插接、热和装配尚未验证，不作为生产发布版。

`tools/migrate_core.py`记录五个旧功能页的迁移，`tools/verify_migrated_core.py`只验证当时97件迁移子集，不能替代当前140件完整工程检查。后续以原生文件和完整系统报告为准，不直接重跑旧迁移脚本覆盖新接口/手工修改。
