# STM32G431 MCU 子板

当前Rev D是可拔插、共地的STM32G431RBT6控制子板，**八页原理图已完成**，位于独立的 [g431_core工程](hardware/g431_core/README.md)。它与inverter功率底板通过两组2×10、2.54 mm直接排针连接；本工程没有覆盖旧LKS文件。

- [KiCad工程](hardware/g431_core/controller.kicad_pro)、[原理图](hardware/g431_core/controller.kicad_sch)、[PDF](hardware/g431_core/review/controller.pdf)
- [当前64脚表](hardware/g431_core/STM32G431RBT6_pin_plan.csv)、[实际XML](hardware/g431_core/review/controller.net.xml)、[BOM](hardware/g431_core/bom/bom.csv)
- [ERC](hardware/g431_core/review/erc.json)、[双板系统检查](hardware/g431_core/review/system_check.txt)
- [分工、供电及40针定义](../docs/controller_daughterboard.md)

当前有140个位号、14项DNP，ERC为0错误、0警告。子板保留MCU、时钟/复位、八路ADC末端RC、SWD、TTL、两路ABZ、两路SPI、四个GPIO指示灯及可选DNP的CAN/HSE。底板的MOS、驱动、模拟前端、比较器、锁存和PWM硬件门控均留在底板。

子板由底板5 V供电，TLV76733DRVR产生本地3.3 V，总负载预算100 mA。原始复位不出板；`CTRL_READY`、`BASE_READY`和`FAULT_N`负责板间状态。PC13/p2接保护后的`BASE_READY_MCU`，PB12/p34接`FAULT_N_MCU`，另有6个GPIO保持NC。PCB尚未设计；共地接口不保证功率故障后的MCU存活。

## LKS历史资料

[hardware/controller.kicad_sch](hardware/controller.kicad_sch)及其 [九页说明](hardware/README.md)仍是LKS32MC451VCT8集中控制两路逆变和一路PFC的旧稿。原100脚表、25路ADC、双逆变/PFC排线及软件资源预算不能直接用于本次G431子板。

历史 [接口](docs/connector.md)、[引脚](docs/pin_assignment.md)、[选型](docs/mcu_candidates.md)、[单MCU评估](docs/single_mcu_evaluation.md)、[ThreadX预算](docs/software_resources.md)及 [供电讨论](docs/power_architecture.md)保留背景价值。新设计以g431_core原生文件和Rev D双板说明为准，固件尚待按新硬件规划。
