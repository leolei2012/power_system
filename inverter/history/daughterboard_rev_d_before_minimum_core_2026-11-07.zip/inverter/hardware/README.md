# Rev D变频功率底板硬件

当前十六页Rev D原理图已完成，配套 [G431控制子板](../../controller/hardware/g431_core/README.md)，底板不再放MCU。实际XML有 **219个位号、3项DNP**，ERC为 **0错误、0警告**。两组2×10、2.54 mm直接排针的40针已与子板逐针核对；供电和状态定义见 [双板说明](../../docs/controller_daughterboard.md)。

- [KiCad工程](inverter.kicad_pro)、[原理图](inverter.kicad_sch)、[当前PDF](review/revd_power.pdf)
- [实际XML](review/revd_power.net.xml)、[BOM](bom/bom.csv)、[完整型号待定](bom/selection_pending.csv)、[公共库待建候选](bom/library_intake.csv)
- [ERC](review/revd_power_erc.json)、[迁移检查](review/revd_power_validation.json)、[双板系统检查](../../controller/hardware/g431_core/review/system_check.txt)
- [PCB状态](PCB_REVIEW.md)、[工程符号](InverterLocal_README.md)、[工程封装及来源](Inverter_Compact_README.md)

## 当前电路

母线12～60 V、直流输入最大10 A，每相连续10 Arms为设计目标，桥PWM 20 kHz。保留2×220 µF/100 V母线电解、两只2.2 µF/100 V旁路、三路低端分流及INA241、四路电压调理和外接NTC。Q1～Q7为BSC110N15NS5，D1为MBRD20150CT-13；器件与封装仍属待应用/热验证的工程候选。

三相比较器、故障汇总/锁存和六路PWM硬件封锁均在底板本地；子板只发PWM、ENABLE和独立BRAKE命令。`CTRL_READY`进入本地许可条件，底板产生`BASE_READY`和开集电极`FAULT_N`返回。ENABLE、PWM、BRAKE与CTRL_READY均在底板保留失联下拉；故障不会依赖MCU固件才关断驱动。

辅助入口J2为12～24 V，底板产生12 V驱动、5 V及本地3.3 V。J101/1、3的`+5V_INV`给子板`+5V_CORE_IN`供电；J102/17、18为U5受限流的`+5V_SENSOR`，两路不能在子板短接。底板`+3V3_INV`与子板`+3V3_MCU`独立，原始NRST不跨板。U1 TPS26600的EP17/引脚8是EFUSE_RTN，不是GND；R8仍DNP，SW1接EFUSE_RTN。

J3/J5为6 mm间距2P焊线孔，J4为 **15 mm间距** 的U/V/W三焊孔；均保留2.0 mm成品孔、4.5 mm铜盘工程定义。J5接外置制动电阻，不用时可开路；U/V/W为原始PWM，输出LC另定。功率母线不设独立预充或专用放电。J7传感器供电口默认DNP，J8接外部10k NTC；其余调试、编码器和SPI接口均在子板。底板只保留D3电源灯，四个GPIO灯已迁入子板。

## 当前交付边界

新底板以 **60×60 mm为目标，尚未布局，也没有配套PCB**。旧六层合板PCB已移至 [Rev C归档](../history/integrated_rev_c_60x60/)，不能对新原理图做同步、DRC或制板依据。PCB层数、安装孔、两板间距及接插件朝向要在新布局阶段确定。

实际BOM已按Rev D导出。精确候选已有项目封装不等于公共库已审核，普通被动件完整型号及部分新器件公共库模型仍有缺口，分别见上述两份清单。图面保持模块内部直接连线、独立模块之间允许标签连接；生成器仅是创建记录，不应覆盖后续人工修改。

额定、热、栅极/采样回路、保护动态和两面装配仍需样机验证。共地排针不是电气隔离，不保证炸管后MCU存活。更早的 [PCB0.1](../history/pcb_0_1_200x140_before_60mm_2026-11-06.zip)及 [Rev A](../history/split_rev_a_2026-11-06.zip)检查仅覆盖各自归档。
