# Rev D 可插拔 G431 子板与功率底板审查

2026-11-06：当前变频器仍由一颗 STM32G431RBT6 控制一套三相桥和一路制动。MCU、调试及传感器接口改在可替换子板，驱动、功率与独立保护留在底板。PFC/LLC 电源板暂停绘图。

## 当前文件与检查

| 项目 | MCU 子板 | 功率底板 |
| --- | --- | --- |
| 原生工程 | [controller.kicad_pro](../../controller/hardware/g431_core/controller.kicad_pro) | [inverter.kicad_pro](inverter.kicad_pro) |
| 原理图 | [8 页](../../controller/hardware/g431_core/controller.kicad_sch) | [16 页](inverter.kicad_sch) |
| PDF | [子板 PDF](../../controller/hardware/g431_core/review/controller.pdf) | [底板 PDF](review/revd_power.pdf) |
| 实际 BOM | [140 位号，14 DNP](../../controller/hardware/g431_core/bom/bom.csv) | [219 位号，3 DNP](bom/bom.csv) |
| ERC | 0 错误、0 警告 | 0 错误、0 警告 |

[系统核对](../../controller/hardware/g431_core/review/system_check.json)覆盖40针配对、64个MCU物理脚、8路模拟与2路数字回传保护，以及16,384组健康/使能/就绪/锁存组合。另检查256组PWM输入与使能组合。[底板迁移核对](review/revd_power_validation.json)确认保留器件参数、封装与DNP未变，97个原器件迁至子板，17处保留引脚连接按明确清单改变。检查不覆盖实际传播延迟、瞬态、温升或装配。

模块内部直接连线，模块之间使用网络标签。两板新PCB尚未设计，60×60 mm为底板目标尺寸；旧六层合板布局及215处未连接状态见[历史Rev C](../history/integrated_rev_c_60x60/README.md)。

## 接口、供电及默认状态

[J101/J102接口定义](../../docs/controller_daughterboard.md)各为2×10、2.54 mm；电气上逐脚对接。J101传6路PWM、ENABLE、BRAKE、CTRL_READY、BASE_READY、FAULT_N及子板5 V，J102传8路模拟量与独立传感器5 V支路。没有跨板并接3.3 V或原始NRST。

底板仍由独立12～24 V辅助输入产生12 V、5 V及本地3.3 V。子板从底板5 V取电，TLV76733产生独立+3V3_MCU，总持续负载预算100 mA。本地TPS3808监视供电，额外检查阻断二极管前的5 V；NRST经具有Ioff的缓冲器成为CTRL_READY。这个信号表示本地供电/复位允许，固件运行许可仍由ENABLE控制。细节见[子板供电设计](../../controller/hardware/g431_core/core_supply_design.md)。

底板以ENABLE_IN与CTRL_READY相与形成ENABLE_QUALIFIED，保持物理下拉；拔下或复位子板时六路桥PWM禁止。BASE_READY由本地逻辑供电与驱动电源就绪相与产生。原比较器、健康链与故障锁存独立在底板封锁桥，不依赖MCU程序。FAULT_N为Q8开集电极回传，10 kΩ上拉仅在子板保护后的本地3.3 V域。故障消除后仍按禁能保持/再使能流程恢复，不能自动重启。制动保持独立软件控制，不与桥的ENABLE/FAULT许可相与。

两板为非隔离共地结构。接口限流与钳位降低部分低能瞬态的风险，不能保证功率管炸毁时MCU不受损；断开两路电源后插拔。

## MCU与采样

完整定义见[当前64脚表](../../controller/hardware/g431_core/STM32G431RBT6_pin_plan.csv)与[资源说明](../docs/pin_assignment.md)。TIM1驱动三相互补PWM，PB12/TIM1_BKIN低有效；TIM8_CH1独立制动。TIM2/TIM4用于两路AB，Z为EXTI；SPI1/SPI3、USART3、SWD及四个GPIO灯保留。PC13读取BASE_READY，6个GPIO未分配。可选经典CAN和HSE默认DNP，PB8保留BOOT0下拉。

八路回传先经360 Ω与BAT54S钳位，再接原100 Ω/1 nF。本地RC为0.46 µs；七路缓冲输出还带底板47 Ω，合计507 Ω。NTC需另计10 kΩ源阻及底板10 nF滤波，不能套用单一0.46 µs。两个ADC不能使三相电流全部同时转换，采样窗口与重构后续核算。保护比较器继续读取底板源端。

BASE_READY与FAULT_N各经1 kΩ和BAT54S再入MCU。所有钳位的总短时正向注入工程预算50 mA，本地TL431提供有限吸收，未实现硬限流。供电说明明确了电源轨、电容稳定性与故障边界。

## 保留的功率目标与后续事项

12～60 V直流母线、直流输入最大10 A、连续相电流10 Arms为设计目标，实际同时可用工作区与热额定仍待验证；桥PWM20 kHz。名义硬件过流±20 A、过压65 V；电流量程1.65 V±50 mV/A，四路电压50:1。65 V是故障门限。两只220 µF/100 V母线电解、一路外接制动电阻接口、原始PWM三相输出保留；按用户决定不设独立预充/母线放电。

三颗2ED2182驱动、七颗BSC110N15NS5ATMA1及分流SOURCE回流结构保持原设计。15 Ω栅阻、自举2.2 µF+100 nF为波形验证起点。普通阻容按国巨，专用分流、大电解和稳定性关键钽电容单独选型。

进入装配发布前仍需完成：普通被动件完整MPN、项目draft器件入库审核、排针排母实际高度/焊盘/正反面与防错插机械检查，以及新PCB的回流、栅极波形、散热、保护响应和供电动态验证。候选与未选项分别见两板bom目录中的library_intake.csv、selection_pending.csv；这些清单不构成采购或生产发布。
