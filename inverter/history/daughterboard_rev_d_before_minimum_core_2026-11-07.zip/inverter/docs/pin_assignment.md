# STM32G431 引脚与资源（Rev D）

2026-11-06：一颗STM32G431RBT6、LQFP64，控制一套三相桥和一路制动。完整逐脚定义见[当前64脚CSV](../../controller/hardware/g431_core/STM32G431RBT6_pin_plan.csv)，已与当前子板实际网表逐脚核对；6脚显式NC，PB8-BOOT0单独下拉。原inverter/hardware目录内的同名CSV保留作Rev C迁移基线，不是当前表。

| 功能 | 引脚 | 外设与复用 |
| --- | --- | --- |
| U/V/W上桥PWM | PA8/PA9/PA10 | TIM1_CH1/2/3，AF6 |
| U/V/W下桥PWM | PB13/PB14/PB15 | TIM1_CH1N/2N为AF6；PB15/CH3N为AF4 |
| 桥故障 | PB12 | TIM1_BKIN，AF6，低有效；FAULT_N经1 kΩ与钳位进入FAULT_N_MCU，本地10 kΩ上拉 |
| 桥使能 | PC4 | GPIO；33 Ω串阻，底板物理下拉 |
| 独立制动 | PC6 | TIM8_CH1，AF4；底板物理下拉 |
| 底板供电就绪 | PC13（物理2脚） | BASE_READY经1 kΩ/钳位到BASE_READY_MCU；本地10 kΩ下拉 |
| I_U/I_V/I_W | PC0/PC1/PC2 | ADC1_IN6 / ADC2_IN7 / ADC1_IN8 |
| V_DC/V_U/V_V/V_W | PC3/PA4/PB0/PB1 | ADC2_IN9 / ADC2_IN17 / ADC1_IN15 / ADC1_IN12 |
| NTC | PB2 | ADC2_IN12 |
| 编码器A | PA0/PA1/PA2 | TIM2_CH1/2 AF1；Z为EXTI2 |
| 编码器B | PB6/PB7/PA3 | TIM4_CH1/2 AF2；Z为EXTI3 |
| SPI A | PA5/PA6/PA7/PA15 | SPI1 SCK/MISO/MOSI AF5；CS为GPIO |
| SPI B | PC10/PC11/PC12/PC9 | SPI3 SCK/MISO/MOSI AF6；CS为GPIO |
| TTL | PB10/PB11 | USART3 TX/RX，AF7 |
| 可选CAN | PA11/PA12 | FDCAN1 RX/TX AF9；现收发器仅按经典CAN，默认DNP |
| SWD | PA13/PA14 | SWDIO/SWCLK，AF0 |
| 四个可编程灯 | PC5/PC8/PD2/PB5 | RUN/FAULT/COMM/AUX；底板供电灯不占GPIO |
| HSE候选 | PF0/PF1 | 晶体与负载电容默认DNP |
| NRST/BOOT | PG10/PB8 | NRST为子板本地MCU_RESET_N；BOOT0 10 kΩ下拉 |
| 未分配 | PC14/PC15/PC7/PB3/PB4/PB9 | 显式NC |

引脚与复用依据：[ST DS12589 Rev 6，图10、表12/13](https://www.st.com/resource/en/datasheet/stm32g431rb.pdf)。SPI B使用SPI3避开下桥PWM。Z为中断输入，未承诺硬件索引清零。ABZ、SPI和TTL均为3.3 V逻辑；接口供电选择5 V不代表信号能直接接5 V或RS-422。

TIM1内部采样触发不额外占脚。两个ADC不能让三相电流全部同时转换：U/V先分配一对同步、W顺序采样，低端分流有效窗口与重构后续验证。七路缓冲ADC路径串阻总计47+360+100=507 Ω，NTC另计其源阻与底板滤波；采样时间按当前电路重新核算。

CTRL_READY从本地复位缓冲产生，不占MCU GPIO，也不代表固件自检完成。功率故障回传不复位MCU；底板硬件独立关桥。固件应在ENABLE/BRAKE低时先配置安全输出、低有效BKIN及故障恢复流程，禁用自动重启。保持SWD，PA15作CS前释放JTDI，保留NRST功能，审查BOOT选项及未使用的UCPD默认功能。

板间40针表与机械方向约束见[子板架构](../../docs/controller_daughterboard.md)。
