# 变频功率底板

当前 **Rev D功率底板十六页原理图已完成**，配套可拔插的 [STM32G431RBT6控制子板](../controller/hardware/g431_core/README.md)。每套使用一颗MCU、一套三相桥和一路制动；功率底板自身不放MCU。两板共地、非隔离，通过两组2×10、2.54 mm直接排针连接。见 [双板设计说明](../docs/controller_daughterboard.md)。

- [当前KiCad与硬件说明](hardware/README.md)、[原理图PDF](hardware/review/revd_power.pdf)
- [实际XML](hardware/review/revd_power.net.xml)、[ERC](hardware/review/revd_power_erc.json)
- [PCB状态与后续审查](hardware/PCB_REVIEW.md)

底板有219个位号、3项DNP，已导出ERC为0错误、0警告。它保留MOS/驱动/自举、三路分流与INA、电压和NTC前端、比较器、故障锁存、六路PWM硬件门控及制动功率支路。保护在底板本地执行，子板拔下、复位或许可失效时由本地下拉禁止驱动。

| 功率指标 | 当前设计目标 |
| --- | --- |
| 拓扑 | 三相两电平桥，U/V/W为原始PWM输出 |
| 直流母线 | 12～60 V DC |
| 直流母线输入电流 | 最大10 A |
| 连续相电流 | 每相10 Arms目标；额定与热验证未完成 |
| 桥PWM | 20 kHz |
| 制动 | 一路软件命令控制，电阻外接，不用时可开路 |
| 辅助输入 | 独立12～24 V，板上产生驱动12 V、5 V和底板3.3 V |

底板通过J101/1、3将`+5V_INV`送至子板`+5V_CORE_IN`；J102/17、18单独提供经U5限流的`+5V_SENSOR`。两者不在子板短接。两板3.3 V独立，原始NRST不跨板。子板侧八路模拟输入及两路状态返回增加了限流/钳位，具体合同见双板说明。

功率底板仍以 **60×60 mm为目标，尚未布局，没有与Rev D对应的PCB**；层数、安装孔和热设计待新布局确认。旧Rev C集成板的六层、双面和孔位不自动成为新底板定稿。功率器件热、采样窗口、故障动态及连接器装配仍须验证；不保证功率级损坏后共地子板完好。

原十八页集成图和未完成的60 mm PCB移至 [Rev C归档](history/integrated_rev_c_60x60/)；更早的 [Rev A](history/split_rev_a_2026-11-06.zip)和 [PCB0.1](history/pcb_0_1_200x140_before_60mm_2026-11-06.zip)继续作历史参考。PFC电源板暂不绘图；本板不加入PFC/LLC、USB或霍尔接口。

`docs/`保留功率指标及选型背景，`hardware/`为当前Rev D功率底板原生图和检查，`history/`存放旧版本，`sim/`和`firmware/`仍为后续工作入口。
