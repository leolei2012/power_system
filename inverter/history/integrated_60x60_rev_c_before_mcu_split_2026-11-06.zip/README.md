# power_system

低压电力电子实验平台。采用 **每块板一颗 MCU，分变频板和电源板，控制与所属功率级同板**。2026-11-06 用户确定先画变频板，暂不绘制 PFC 电源板。本轮变频板采用 **STM32G431RBT6（LQFP64）**，已建立十八页 Rev C 集成原理图审查稿。最新分工见 [合板方案](docs/integrated_board.md)。

| 模块 | 当前分工与状态 |
| --- | --- |
| [变频板 inverter](inverter/README.md) | STM32G431RBT6、一套三相桥、采样保护和一路制动；十八页 Rev C 原理图和 60×60 mm 六层 PCB0.2 布线工作稿 |
| [电源板规划](docs/integrated_board.md#板卡分工) | 暂不绘图；保留 Boost / Vienna 两个版本和 PFC＋LLC 单 MCU 控制的讨论，资源可行性未验证 |
| [controller 旧方案](controller/README.md) | 独立 LKS 控制板停止推进，九页草稿和资料留作历史参考 |
| [实验链路](vfd/docs/architecture.md) | 先直流供电实验，未来再考虑市电版本 |
| [长期规划](docs/roadmap.md) | 各板独立验证和组合；LLC 已恢复讨论，尚未冻结实现 |

变频板继续采用 12～60 V 母线、直流输入最大 10 A、每相连续 10 Arms 设计目标及 20 kHz 桥 PWM；名义 ±20 A 过流、65 V 过压和外接制动支路继续保留。[完整规格](inverter/docs/spec.md)。这些数值不自动成为电源板 PFC 中间母线或 LLC 输出规格。

辅助电源仍先用独立 12～24 V 适配器，功率母线可由实验直流电源或后续自研模块提供；每板电源、参考地及隔离独立设计。取消旧 controller 与 inverter 的 24 脚控制排线和专用 5 V 供电关系，ENABLE/FAULT/制动仍作为板内网络保留。板间通信和联锁尚未定型。

两块相同变频板可分别用于实验交流源和电机控制，各自运行本板实时控制。电源板对外已确定需要辅助低压和功率母线两路输出；功率母线已定 12～60 V 可调、最大 10 A（最高 600 W），辅助口电压/电流待定。加入 LLC 后的候选主功率链路是 PFC → 中间直流母线 → LLC → 直流输出 → 变频板；输入、变比、功率和输出范围仍需匹配。当前不接市电，不把历史 390 V / 1～2 kW 草案套到低压实验板。

## 原理图与设计状态

[变频板十八页 KiCad Rev C](inverter/hardware/README.md)保留 MCU、供电、三相桥、采样、故障锁存、制动及全部外部接口；实际 BOM 为 **313 条记录、17 条 DNP**。[60×60 mm 六层 1 oz 双面 PCB0.2](inverter/hardware/PCB_REVIEW.md)正在布线，四个 M2 孔；最终 DRC、待连接、原理图一致性及导出物待本轮整合后核对。Q1～Q7 改为 TDSON-8 的 BSC110N15NS5，D1 为 DPAK 的 MBRD20150CT-13；项目紧凑封装和可采购候选仍须完成应用、热及装配验证。

本版保留八路 ADC、两路 ABZ、两路独立 SPI、TTL、SWD、可选经典 CAN 和五个 LED；MCU 七脚 NC。CAN 分支全 DNP，HSE 为可选 DNP；外部信号暂按 3.3 V 单端，外设 5 V 供电连接默认 DNP。接口仍需核对具体传感器、电平防护和连接器。ThreadX 方向保留，本阶段以硬件为主。

旧十三页分板 Rev A 已归档为 [split_rev_a_2026-11-06.zip](inverter/history/split_rev_a_2026-11-06.zip)，独立 [controller 九页](controller/hardware/README.md)继续作历史参考；旧报告不覆盖当前 Rev C；200×140 mm 四层 PCB0.1 另有 [改板前归档](inverter/history/pcb_0_1_200x140_before_60mm_2026-11-06.zip)。

## 器件与设计约定

器件统一在立创商城国内站选型，记录厂家完整型号、C 编号、商品页、封装及可核实的采购信息；电气及脚序以原厂规格书为准。普通贴片小阻容统一 YAGEO（国巨），分流、制动电阻、母线大电解等专项选型。公共库为相邻 kicad_library 仓库，新芯片完整型号确认后按其流程维护。

当前 [实际位号 BOM](inverter/hardware/bom/bom.csv)和 [原理图审查记录](inverter/hardware/design_review.md)对应当前 Rev C；完整型号待建项目见 [现行清单](docs/inverter_library_todo.csv)，未定料号见 [待选清单](docs/inverter_selection_todo.csv)。旧版 [建库清单](docs/library_build_list.md)仍为选型背景，具体库状态以公共库台账为准。变频板仍以 ATK-PD6010B 为主要硬件参考，暂用两只 220 uF/100 V 母线电解及两只国巨 2.2 uF/100 V 旁路，不设功率母线独立预充/限浪涌或专用放电支路；辅助输入保护和制动保留。

设计参考统一存放在 [reference](reference/README.md)；[ATK-PD6010B](reference/ATK-PD6010B/README.md)包含取得的原理图、硬件资料、来源与对照记录。旧 [交接记录](docs/schematic_handoff.md)和 [任务书](docs/schematic_agent_task.md)的分板要求已被新合板方案取代，其电气分析仍可逐项复用。
