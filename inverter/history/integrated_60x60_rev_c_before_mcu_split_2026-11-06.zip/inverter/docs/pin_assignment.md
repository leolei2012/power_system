# STM32G431 变频板引脚与资源

2026-11-06，Rev B 原理图采用 STM32G431RBT6，LQFP64。完整逐脚定义见 [64 脚 CSV](../hardware/STM32G431RBT6_pin_plan.csv)，与本版实际 KiCad 网表独立比较通过；7 脚显式 NC，PB8-BOOT0 单独下拉。公共库未在本轮入库。

| 功能 | 引脚 | 外设与复用 |
| --- | --- | --- |
| U/V/W 上桥 PWM | PA8/PA9/PA10 | TIM1_CH1/2/3，AF6 |
| U/V/W 下桥 PWM | PB13/PB14/PB15 | TIM1_CH1N/2N 为 AF6，**CH3N/PB15 为 AF4** |
| 桥故障 | PB12 | TIM1_BKIN，AF6，低有效；本地上拉 |
| 桥使能 | PC4 | GPIO，外部下拉 |
| 独立制动 | PC6 | TIM8_CH1，AF4；外部下拉 |
| I_U / I_V / I_W | PC0/PC1/PC2 | ADC1_IN6 / ADC2_IN7 / ADC1_IN8 |
| V_DC / V_U / V_V / V_W | PC3/PA4/PB0/PB1 | ADC2_IN9 / ADC2_IN17 / ADC1_IN15 / ADC1_IN12 |
| NTC | PB2 | ADC2_IN12 |
| 编码器 A | PA0/PA1/PA2 | TIM2_CH1/2 AF1；Z 为 EXTI2 |
| 编码器 B | PB6/PB7/PA3 | TIM4_CH1/2 AF2；Z 为 EXTI3 |
| SPI A | PA5/PA6/PA7/PA15 | SPI1 SCK/MISO/MOSI AF5；CS 为 GPIO |
| SPI B | PC10/PC11/PC12/PC9 | SPI3 SCK/MISO/MOSI AF6；CS 为 GPIO |
| TTL | PB10/PB11 | USART3 TX/RX，AF7 |
| 可选 CAN | PA11/PA12 | FDCAN1 RX/TX，AF9；现收发器仅按经典 CAN |
| SWD | PA13/PA14 | SWDIO/SWCLK，AF0 |
| 四个可编程灯 | PC5/PC8/PD2/PB5 | RUN/FAULT/COMM/AUX；另有无 GPIO 的供电灯 |
| HSE 候选 | PF0/PF1 | 当前晶体/负载电容 DNP |
| NRST / BOOT | PG10 / PB8 | NRST 与 LOGIC_POWER_OK 同网；BOOT0 10 kΩ 下拉 |
| 未分配 | PC13/PC14/PC15/PC7/PB3/PB4/PB9 | 原理图显式 NC |

脚号与复用依据为 [ST DS12589 Rev 6 图 10、表 12/13](https://www.st.com/resource/en/datasheet/stm32g431rb.pdf)。SPI B 使用 SPI3，避免 SPI2 与三相下桥 PWM 争用。Z 采用中断输入，不承诺硬件索引自动清零。ABZ 和 SPI 暂按 3.3 V 单端，具体外设仍需匹配。

TIM1 的内部采样触发可继续规划，不占额外引脚；具体 TRGO/注入组/双 ADC 时序需按参考手册和低端分流有效窗口设计。两个 ADC 不能把三相电流全部同时转换；CSV 的 ADC 分配是本轮起点，不是已经验证的三相采样算法。

固件初始化应保持 ENABLE/BRAKE 低，先配置安全定时器状态、低有效 BKIN 和故障恢复流程，再允许 PWM。保持 SWD，PA15 作 CS 前释放 JTDI，保留 NRST 功能，审查 BOOT 选项以及不用的 UCPD 默认功能。NRST 低也会进入本地健康链封锁桥；功率故障另走 FAULT_N，不复位 MCU。
