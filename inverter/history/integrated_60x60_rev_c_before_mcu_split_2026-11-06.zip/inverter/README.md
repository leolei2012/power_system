# 变频板

2026-11-06：本轮采用 **STM32G431RBT6（LQFP64）＋采样保护＋栅极驱动＋三相功率桥同一 PCB**，每块板一颗 MCU、一套三相桥和一路制动，十八页 Rev C 原理图已迁移到紧凑方案。当前先做变频板，PFC 电源板暂不绘图；已有 PFC＋LLC 规划保留。见 [合板方案](../docs/integrated_board.md)。

同一套三相硬件可在交流源和电机变频模式中选择；需要同时做交流源和电机控制时使用两块板，各自控制。输出滤波仍须按交流源用途另定，当前为直接 U/V/W PWM。

功率母线由实验直流源或后续电源板提供，须满足本板 12～60 V 规格；辅助输入仍为独立 12～24 V。板上产生驱动与 MCU 所需电压，取消给独立 controller 输出 5 V 的必需关系，外部传感器供电另核。

## 规格摘要

| 项 | 值 |
|----|----|
| 拓扑 | 三相两电平桥 |
| 直流母线 | **12～60 V DC，已确定** |
| 交流输出 | 三相，随母线变化；60 V 母线理想 SVPWM 线性区约 42.4 V 线电压有效值上限 |
| 直流母线输入电流上限 | **10 A，已确定电流定义** |
| 连续输出相电流上限 | **每相 10 A_rms，正弦峰值约 14.1 A**；另计 PWM 纹波 |
| 直流输入功率上限 | 120～600 W，随 12～60 V 母线变化 |
| 额定输出功率 | 待相电流、工况及损耗核算 |
| 开关频率 | 20 kHz |

完整指标见 [docs/spec.md](docs/spec.md)。

板内为 12 V 驱动、5 V、3.3 V；本轮精确候选及工程封装见 [紧凑封装说明](hardware/Inverter_Compact_README.md)，[首轮选型评估](docs/component_selection.md)保留为历史背景。

## 工程状态

[十八页 KiCad Rev C](hardware/README.md)、[BOM](hardware/bom/bom.csv)和 [审查记录](hardware/design_review.md)对应紧凑集成版，313 条记录、17 条 DNP。[60×60 mm 六层 1 oz 双面 PCB0.2](hardware/PCB_REVIEW.md)正在布线，四个 M2 孔，最终连通、DRC、原理图一致性和导出物待本轮整合。全部功能/接口保留；MOS、二极管和部分机械器件更换后，热、额定、采购及装配仍需验证。

旧 200×140 mm 四层 PCB0.1 的布局/布线及通过结果只对应 [改板前归档](history/pcb_0_1_200x140_before_60mm_2026-11-06.zip)。旧分板 Rev A 另有 [历史归档](history/split_rev_a_2026-11-06.zip)，controller 目录也只作参考；本板与电源板分别构建固件。

本版保留八路 ADC、两路 ABZ、两路独立 SPI（SPI1/SPI3）、TTL、SWD、可选经典 CAN 和五个 LED（电源灯＋四个可编程灯），MCU 七脚 NC，见 [完整 64 脚表](hardware/STM32G431RBT6_pin_plan.csv)。CAN 分支全 DNP，HSE 可选 DNP；外部信号暂为 3.3 V 单端，外设 5 V 供电连接默认 DNP，不能接入未经调理的 5 V 逻辑。

继续审核电源保护、热、采样盲区、动态故障和连接器/传感器电平；三路电流在两个 ADC 上的有效采样窗口也须验证。第一版不加入 USB 或霍尔，不在本板增加 LLC/PFC 控制排线。

## 目录

- docs/：规格、接口和选型背景。
- hardware/：当前十八页 Rev C 集成原理图、60×60 mm 六层 PCB0.2、引脚表、BOM、预览和核对报告。
- history/：合板前的分板 Rev A 历史归档。
- sim/：功率电路和算法仿真规划。
- firmware/：固件占位，按本板独立 MCU 重新规划。
- reference/：原厂资料与硬件对照；平台公共参考见 ../reference/。
