# 变频合板实际 BOM

当前 bom.csv 与 ../review/bom.csv 来自 Rev C / PCB0.2 的实际 KiCad XML，**313 条位号记录，含测试点和 17 条默认 DNP**。本轮为 60×60 mm 六层 1 oz 双面装配；正在布线，BOM 属于工程审查资料，尚非采购/装配发布清单。[设计审查](../design_review.md) / [PCB 状态](../PCB_REVIEW.md)

本次已将七颗 MOS 改为 BSC110N15NS5（完整订货码 BSC110N15NS5ATMA1）、D1 改为 MBRD20150CT-13，并为保险丝、电感、按键及低压头选取精确候选。功率 J3/J4/J5 为工程焊线孔，不需采购端子：J3/J5 间距6 mm，J4 间距15 mm。实际引脚和封装以 XML/原生图及 [compact_design.json](../tools/compact_design.json) 为准，早期候选不能覆盖本轮实际值。

[待建公共物料](../../../docs/inverter_library_todo.csv)只列完整型号已确定、尚无公共 reviewed 物料的候选；[待选型号](../../../docs/inverter_selection_todo.csv)另列型号未完整确定的位号分组。所有当前器件均已关联几何封装；“待建公共库”不等于“PCB 空封装”。工程草稿与官方标准封装来源见 [紧凑封装说明](../Inverter_Compact_README.md)。普通国巨小阻容等仍须补齐精确型号、电压、精度与偏压有效容量；无需本轮替换主 BOM 来掩盖 TBD。

R8 新增为 DNP，撤去 AUX_FUSED 对 SHDN 的高压上拉，保持 SW1 复位及 EFUSE_RTN。D2、CAN、HSE 和传感器 5 V 连接等可选项按实际 DNP 装配；外接制动电阻及 NTC 不计入板载装配。J5 不用时开路，禁止短接。

旧 candidates_pre_schematic_2026-11-01.csv 是历史分组选型。200×140 mm PCB0.1 的实际 BOM/报告在 [改板前归档](../../history/pcb_0_1_200x140_before_60mm_2026-11-06.zip)，分板 Rev A 的 BOM 在 [Rev A 归档](../../history/split_rev_a_2026-11-06.zip)；均不能作为本轮采购清单。
