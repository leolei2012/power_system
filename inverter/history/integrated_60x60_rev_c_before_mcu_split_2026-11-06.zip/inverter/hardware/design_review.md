# STM32G431 变频合板审查记录

2026-11-06，当前为 Rev C / PCB0.2 紧凑电路审查稿：60×60 mm、六层 1 oz、双面装配、四个 M2 孔，正在布线，最终整合检查待完成。控制、驱动及功率级已合并为一块变频板，具体绘图型号为 **STM32G431RBT6 / LQFP64 / 128 KB Flash / 32 KB SRAM**。本轮只推进变频板；电源板 PFC/LLC 保留规划，暂停绘图。

图面按功能模块组织：**模块内部直接连线，模块之间允许通过网络标签连接**，包括同页模块；不为了全实线而跨模块拉长线。电源/地采用各模块局部母线与标准符号。MCU 与去耦组、偏置发生器与三相电流通道、各相比较窗口、独立电源监控/制动功能等按此划分，连续功率和反馈回路保留实线。重排前快照保存在 [Rev B 原图归档](../history/rev_b_before_readability_2026-11-06.zip)，全器件、全部物理引脚连通分组及参数/DNP/封装等价核对见 [重排检查报告](review/readability_equivalence.txt)。新加的 VBUS PWR_FLAG 是非 BOM 的 ERC 电源来源声明，不增加实际器件。

## 交付与检查

[原生工程](inverter.kicad_pro)、[十八页原理图](inverter.kicad_sch)、[PDF](review/inverter.pdf)、[313 条位号 BOM](bom/bom.csv)、[64 脚分配](STM32G431RBT6_pin_plan.csv)为本轮对应入口，PDF/检查报告须在最终整合时同步版本与时间。

历史 Rev B 曾通过 ERC、独立网表及 8192 种健康/使能/锁存组合、128 种 PWM 图样检查。本轮更换 MOS 物理引脚/封装并将 R8 改 DNP，当前最终结果待重新导出核对；[检查报告](review/connectivity_check.txt)须按文件哈希和日期阅读，不能将旧通过结论迁用于 Rev C/PCB0.2。

另将当前 XML 与归档 Rev A 逐旧器件引脚比较：删除 J1/J6、三处传感器电源网名变更之外，原功率、采样及保护电路连接保持一致。这是当时迁移检查；本轮 MOS 物理脚扩展与 R8 DNP 由 [compact_design.json](tools/compact_design.json)单独记录。静态检查不覆盖模拟瞬态、MOS/磁件/电容温升、栅压、软件初始化或实物保护响应。

| 页 | 功能 |
| --- | --- |
| 1 | 总览与层级导航 |
| 2～4 | 12～24 V 辅助入口、12 V、5 V、3.3 V、可选传感器电源及监控 |
| 5 | 12～60 V 母线、2×220 µF/100 V、2×2.2 µF/100 V、一路制动 |
| 6～8 | U/V/W 半桥、驱动、自举与各自低端分流 |
| 9～11 | 三路电流、四路电压、NTC、参考与独立比较器 |
| 12～13 | 故障锁存、健康链及六路硬件 PWM 封锁 |
| 14～15 | G431 最小系统、八路 ADC RC、VDDA/VREF |
| 16～18 | 两路 ABZ、两路 SPI、SWD/TTL/可选 CAN、LED、板内控制及 HSE 候选 |

## MCU 与板内控制

三相桥使用 TIM1：PA8/PA9/PA10 为 CH1/2/3，PB13/PB14/PB15 为 CH1N/2N/3N；**PB15 使用 AF4**，其余五路使用 AF6。六路经过 33 Ω，再进入原硬件与门。PC4 经 33 Ω 驱动 ENABLE；PC6/TIM8_CH1 经 33 Ω 独立驱动 BRAKE。[ST DS12589 Rev 6，图 10、表 12/13](https://www.st.com/resource/en/datasheet/stm32g431rb.pdf)

Q8 开集电极 FAULT_N 新增本地 10 kΩ 上拉，接 PB12/TIM1_BKIN，按低有效配置。外部比较器、锁存和与门仍直接封锁桥，不依赖 MCU 或 BKIN 配置。初始化必须先保持 ENABLE/BRAKE 低，设置安全输出状态与 BKIN 后再允许 MOE；关闭自动恢复输出，故障后按既定禁能流程恢复。

U6 TPS3808 的 LOGIC_POWER_OK 同时作为 G431 NRST、SWD 复位和复位按键网络。**普通桥故障不接 NRST**，保留诊断及独立制动控制。按键、调试器或内部复位若拉低 NRST，也会经过 LOGIC_POWER_OK 关闭桥并置位原故障锁存；重启后仍需健康且 ENABLE 低保持至少 1 ms，再主动使能。

ENABLE、六路 PWM、BRAKE 原物理下拉均保留，MCU 复位高阻时封锁桥且关闭制动。制动不与桥 ENABLE/故障许可相与，硬件门限和软件制动策略分别处理。

## 电源与模拟

VDD 四脚各有 100 nF，VBAT 接 3.3 V 并有独立 100 nF，另设 4.7 µF。VSSA/VSS 接系统 GND，即分流低端/DC−；本封装没有外部 VCAP。VDDA 与 VREF+ 通过各自 0 Ω 引入，分别配 100 nF+1 µF。VREF+ 使用外部约 3.3 V，内部 VREFBUF 保持关闭；**1.65 V 只用于电流放大器偏置**。[ST AN5093，供电与复位要求](https://www.st.com/resource/en/application_note/an5093-getting-started-with-stm32g4-series--hardware-development-boards-stmicroelectronics.pdf)

七路缓冲信号保留源端 47 Ω，之后增加本地 100 Ω/1 nF；硬件比较器继续采在源端。NTC 保留原 10 kΩ/10 nF，也经过新增本地 RC。采样时间和 PWM 窗口需按这些实际源阻抗验证。G431 只有两个 ADC，不能声称三路相电流由三个 ADC 同时转换；本表先分配 U/V 同步一对、W 顺序转换，最终有效采样及重构需审查。

U4 的完整型号为 TPS7A2033PDBVR，额定输出 300 mA，由 MCU、模拟、逻辑、可选 CAN 和 LED 共用；实际可用电流还受 5 V→3.3 V 压降和散热限制，需完成最坏电流/热预算。此前记为 200 mA 的说法更正为 300 mA，依据 [TI TPS7A20 Rev H](https://www.ti.com/lit/ds/symlink/tps7a20.pdf)。原 U5 改为 +5V_SENSOR，总目标 0.5 A；J7、两路 ABZ 和两路 SPI 的 5 V 供电连接默认断开。5 V 外设供电不代表接口能接受 5 V 逻辑。

## 外部接口与装配选项

TIM2/TIM4 分别用于两路 AB，Z 接 EXTI2/3；未承诺硬件自动索引清零。两路独立 SPI 使用 SPI1/SPI3，避免 SPI2 与 TIM1 下桥臂引脚冲突。TTL 使用 USART3，SWD 保留 PA13/14。PA15 作片选前须释放 JTDI；PB8 为 BOOT0，下拉 10 kΩ；复位/启动选项以及不用的 UCPD 默认功能须按 ST 要求配置。

ABZ 暂为 3.3 V 单端输入，不能直接接 5 V 或 RS-422 差分编码器；最终型号确定后再补线接收器、ESD、线缆和速度指标。SPI 同样为 3.3 V。CAN 全物理层默认 DNP；若装配 SN65HVD232，仅按经典 CAN、最高 1 Mbps 范围评估，不承诺 CAN-FD。120 Ω 仅总线物理端点装配。[TI SN65HVD23x](https://www.ti.com/lit/ds/symlink/sn65hvd232.pdf)

Y1 和两只负载电容默认 DNP，8 MHz 仅为 HSE 候选，CL/ESR/驱动等级/起振裕量未选定；初次可用 HSI16/PLL，使用 CAN 前须校核时钟误差。五只 LED 包括一只供电灯、四只可编程灯。

本版 17 条默认 DNP：R8、D2、J7、R100/R107/R113/R119、U31/C82/J15/R126～R129、Y1/C83/C84。R8 撤去原 AUX_FUSED 对 TPS26600 SHDN 的 12～24 V 上拉；使用内部约2.7 V偏置，SW1仍拉到EFUSE_RTN，EP17/引脚8也保持EFUSE_RTN而非GND。外接制动电阻和 NTC 不计入板载 BOM。J5 接外置制动电阻，不用时开路，禁止短接；参考目标 5.6 Ω、±5%、1 kW，仍需按再生能量和散热定型。

## 保留的功率设计与定稿缺口

功率规格仍为 12～60 V、DC 输入最大 10 A、相电流连续 10 Arms 设计目标，20 kHz 桥 PWM。名义 ±20 A 过流、65 V 过压；电流量程为 1.65 V±50 mV/A，四路电压为 50:1。65 V 是故障门限，不能作正常工作上限。当前三相端子为原始 PWM，未装输出 LC。独立预充/母线放电按用户决定不设置。

三颗驱动 COM、下侧栅源下拉、VCC 去耦及 INA241 高端各接对应 SOURCE，分流低端才是 GND，合板不改变这些回流。Q1～Q7 改为 TDSON-8 的 BSC110N15NS5（订货码 BSC110N15NS5ATMA1），物理1/2/3=S、4=G、5/6/7/8=D，大散热焊盘重复编号5；D1改为MBRD20150CT-13/DPAK，官方DS37086 Rev4-2（September 2026）确认1/3=A、2/tab=K，实际到货机械变体及热仍待确认；自举 2.2 µF+100 nF、栅阻 15 Ω 为待波形验证起点。详细原设计分析保留于 [Rev A 归档](../history/split_rev_a_2026-11-06.zip)内的 hardware/design_review.md。

| 范围 | 生产发布/装配前需完成 |
| --- | --- |
| 物料与封装 | 紧凑精确候选和实际封装已入图，但仍属项目draft；公共待建及待选清单分别维护。J4实际15 mm焊孔间距，J3/J5为6 mm；HCTL 0.70 mm孔、MOS派生焊盘及到货匹配/装配仍须审核；普通国巨阻容、LED/HSE完整型号仍待选 |
| 功率输入 | D1 国内物料与热；熔断器 DC 分断/I²t；D2 默认 DNP，TVS 钳位能量与 100 V 电容裕量未验证 |
| 电源 | 辅助源容差/浪涌与转换器输入协调；已选4.7 µH MWSA0603S-4R7MT的最坏峰值/温升/30 V绝对最大与实际布局；3.3 V 总电流、热、外设供电及掉电反灌 |
| 栅极与功率热 | 12 V 最差角点的实际栅压、MOS 热态/开关损耗、分流温升、PCB铜区、死区/自举补电/负VS |
| 采样保护 | 低端分流盲区、ADC有效窗口/RC、误差、总关断延迟、复位RC/短脉冲、噪声与故障期间电源完整性 |
| 外部接口 | 编码器/模块电气标准、ESD/长线、失电注入；CAN时钟/共模与是否需要隔离；交流源LC/阻尼另设计 |

当前 [PCB0.2 板级审查](PCB_REVIEW.md)记录六层紧凑方案、热边界和最终验证待填栏；旧PCB0.1通过结果在改板前归档。当前XML为313位号、17 DNP；MOS物理脚扩展和R8 DNP是明确迁移项，其余连接按实际图核对。G431等公共物料已reviewed不表示工程仍用的草稿/标准封装自动同步；见 [符号说明](InverterLocal_README.md)、[紧凑封装来源](Inverter_Compact_README.md)。本轮不修改公共库，复查流程见 [工具说明](tools/README.md)。
