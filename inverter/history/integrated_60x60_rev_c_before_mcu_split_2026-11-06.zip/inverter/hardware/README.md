# STM32G431 变频合板硬件

2026-11-06：当前为 **Rev C / PCB0.2：60×60 mm、六层 1 oz、双面装配、四个 M2 孔**的集成变频板审查稿，18 页原理图保留一颗 STM32G431RBT6、采样保护、三颗半桥驱动、一套三相桥和一路制动。本轮正在布线，最终 DRC、连通/一致性及导出物待整合检查；PFC 电源板仍暂停绘图。

- [KiCad 工程](inverter.kicad_pro) / [原理图入口](inverter.kicad_sch) / [实际位号 BOM](bom/bom.csv)
- [当前 60 mm 原生 PCB](inverter.kicad_pcb) / [布线工作副本](review/compact_work/inverter.kicad_pcb) / [PCB 方案和验证栏](PCB_REVIEW.md)
- [18 页 PDF](review/inverter.pdf) / [64 脚表](STM32G431RBT6_pin_plan.csv) / [引脚说明](../docs/pin_assignment.md)
- [设计审查与未定项](design_review.md) / [待建公共物料](../../docs/inverter_library_todo.csv)
- [工程草稿符号](InverterLocal_README.md) / [紧凑封装及来源](Inverter_Compact_README.md)
- [ERC](review/erc.rpt) / [网表核对](review/connectivity_check.txt) / [板读回](review/pcb_check.txt) / [DRC](review/pcb_drc.json)

主目录板文件、PDF、预览及报告须在布线结束后同步到本轮文件；阅读报告先核对版本、时间和哈希。历史 Rev B/PCB0.1 的通过结论不能用于 Rev C/PCB0.2。

## 当前电路和机械

母线 12～60 V，直流输入最大 10 A，每相连续 10 Arms 为设计目标，桥 PWM 20 kHz。保留 2×220 µF/100 V、三路低端分流和 INA241、四路电压缓冲及外接 NTC。Q1～Q7 改用 BSC110N15NS5，订货码 BSC110N15NS5ATMA1 / C412739，TDSON-8；D1 改用 MBRD20150CT-13 / C151357，DPAK。引脚、实际封装变体及热边界见 [PCB 审查](PCB_REVIEW.md)。

外部比较器、故障锁存和六路硬件 PWM 封锁保留，FAULT_N 另接 TIM1 BKIN。制动由本板 MCU 独立 TIM8 输出控制。J3/J5 为 6 mm 间距的 2P 焊线孔，J4 为 **15 mm 间距**的 U/V/W 三焊孔；均为 2.0 mm 成品孔、4.5 mm 铜盘工程候选。J5 外接制动电阻，不用时开路；U/V/W 仍为原始 PWM，未加入尚未定型的输出 LC。功率母线不设独立预充或专用放电。

辅助输入独立 12～24 V，J2 为 JST PH 2P。板内产生 12 V、5 V、3.3 V；U4 TPS7A2033PDBVR 的额定输出为 **300 mA**，共用负载与散热须核算。L1/L2 同用 4.7 µH MWSA0603S-4R7MT。R8 保持原位号及焊盘但 DNP，移除对 TPS26600 SHDN 的高压外部上拉；SW1 仍拉至 EFUSE_RTN。U1 的 EP17/引脚8为 EFUSE_RTN，不能当 GND。

13 个连接器的 46 针及原针序保留：两路 ABZ、两路独立 SPI、TTL、SWD、可选经典 CAN、NTC 和传感器电源等。J7～J15 使用 1.27 mm 单排候选；逻辑仍为 3.3 V 单端，不接受未经调理的 5 V/RS-422。可选传感器电源总目标 0.5 A，J7 及四路 5 V 供电连接默认 DNP；CAN 分支、HSE 候选同样保留 DNP。五只 LED 为电源灯加四个可编程灯，MCU 七脚 NC。

## 文件和定稿边界

实际 BOM 共 **313 条位号记录，含测试点及 17 条 DNP**。新增紧凑器件已有精确候选与物理封装，并非空封装；公共物料台账是否 reviewed、项目实际是否采用对应定义、器件应用是否验证是三项不同状态。普通国巨小阻容、LED/HSE 等仍有完整料号或额定待选项，不能据此直接采购装配。

当前项目替换记录见 [compact_design.json](tools/compact_design.json)，封装几何及采购来源见 [紧凑封装说明](Inverter_Compact_README.md)。本轮没有修改公共库；相邻公共库中已有的 reviewed 物料也不表示本项目使用的其他符号/焊盘已同步通过审核。额定、热、采样窗口、保护时序、输入钳位及外接接口保护仍需完成。

图面继续遵循：**功能模块内部用直接连线，模块之间可以用标签连接**；连续功率、栅极/自举、反馈和采样调理回路应可沿线阅读。原生 KiCad 文件为准，[创建/检查工具](tools/README.md)不得用于覆盖后续手工修改。

旧 200×140 mm 四层 PCB0.1 及其检查已作 [改板前归档](../history/pcb_0_1_200x140_before_60mm_2026-11-06.zip)；旧十三页分板 Rev A 位于 [更早归档](../history/split_rev_a_2026-11-06.zip)。旧 controller 目录只作历史参考。
